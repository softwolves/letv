#!/bin/bash
error_yum(){
        language
        if [ $? -eq 0 ];then
                clear
                echo
                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                echo "错误:本机YUM不可用，请正确配置YUM后重试."
                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                echo
                exit
        else
                clear
                echo
                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                echo "ERROR:Yum is disable,please modify yum repo file then try again."
                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                echo
                exit
        fi
}
test_yum(){
#set yum configure file do not display Red Hat Subscription Management info.
        if [ -f /etc/yum/pluginconf.d/subscription-manager.conf ];then
        sed -i '/enabled/s/1/0/' /etc/yum/pluginconf.d/subscription-manager.conf
        fi
        yum clean all &>/dev/null
        repolist=$(yum repolist 2>/dev/null |awk '/repolist:/{print $2}'|sed 's/,//')
        if [ $repolist -le 0 ];then
                error_yum
		exit 1
        fi
}
test_yum
yum -y install gcc gcc-c++
#4.假设安装的目录为/home/ffmpeg(如果没有，请自行创建)
dir=/home/ffmpeg
if [ ! -d $dir ];then
mkdir -p /home/ffmpeg
fi
#安装yasm软件包
tar zxf yasm-1.2.0.tar.gz
cd yasm-1.2.0
./configure >/dev/null
make && make install >/dev/null
cd ..
#下载编译安装x264,如果没有可以下载git，然后clone。
#yum -y  install git 
#git clone git://git.videolan.org/x264.git

tar -zxf x264.tar.gz
cd x264/
./configure --enable-shared >/dev/null
make && make install >/dev/null
cd ..
#安装fdk-acc
tar zxf fdk-aac-0.1.4.tar.gz
cd fdk-aac-0.1.4
./configure
make && make install
cd ..
#安装libogg
tar zxf  libogg-1.3.1.tar.gz
cd  libogg-1.3.1
 ./configure
make
make install
cd ..
#下载安装libvorbis
tar zxf  libvorbis-1.3.3.tar.gz 
cd  libvorbis-1.3.3
./configure
make
make install
cd ..
#3.6安装lame
tar zvxf lame-3.99.5.tar.gz
cd lame-3.99.5
./configure --enable-shared
make
make install
cd ..
# 编译安装ffmpeg
tar zvxf ffmpeg-2.8.6.tar.gz
cd ffmpeg-2.8.6
./configure --enable-shared --enable-gpl --enable-libfdk_aac --enable-libmp3lame  --enable-libx264  --enable-nonfree
make
make install
echo "/usr/local/lib" >> /etc/ld.so.conf
ldconfig
