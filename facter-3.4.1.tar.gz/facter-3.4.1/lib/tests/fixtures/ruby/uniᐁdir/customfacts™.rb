# encoding: utf-8
Facter.add('somefact™') do
  setcode do
    'other™'
  end
end
