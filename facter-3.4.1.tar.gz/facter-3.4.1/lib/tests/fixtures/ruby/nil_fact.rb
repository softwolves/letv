Facter.add(:foo) do
    setcode do
        nil
    end
end
