Facter.add(:foo) do
    setcode ''
end