Facter.add(:foo) do
    setcode do
        -101
    end
end
