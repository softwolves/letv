Facter.foo(:add) do
end
