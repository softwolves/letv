Facter.add(:foo) do
    setcode do
        false
    end
end
