Facter.add(:foo) do
    setcode do
        1234
    end
end
