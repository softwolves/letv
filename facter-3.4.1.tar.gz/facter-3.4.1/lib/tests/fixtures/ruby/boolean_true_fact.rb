Facter.add(:foo) do
    setcode do
        true
    end
end
