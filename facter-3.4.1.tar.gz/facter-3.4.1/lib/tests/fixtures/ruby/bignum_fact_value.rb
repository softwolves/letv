Facter.add('bignum_fact') do
  setcode do
    12345678901
  end
end
