Facter.add(:foo, :name => :bar, :type => :aggregate) do
end

Facter.add(:foo, :name => :bar) do
end
