Facter.add(:foo) do
    setcode do
        12.34
    end
end
