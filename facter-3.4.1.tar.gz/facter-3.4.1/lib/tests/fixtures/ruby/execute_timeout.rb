Facter::Core::Execution.execute("#{RbConfig.ruby} -e 'sleep 15'", :timeout => 1)
