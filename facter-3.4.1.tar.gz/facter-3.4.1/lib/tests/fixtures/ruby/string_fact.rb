Facter.add(:foo) do
    setcode do
        'hello world'
    end
end
