raise 'nope' unless Facter.version == Facter::FACTERVERSION
Facter.debug Facter.version
