echo this script fails
exit 1
