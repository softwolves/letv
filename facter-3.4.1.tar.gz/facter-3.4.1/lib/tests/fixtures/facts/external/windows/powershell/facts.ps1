echo ps1_fact1=value1
echo ps1_fact2=
echo ps1_fact3
echo PS1_fact4=value2
