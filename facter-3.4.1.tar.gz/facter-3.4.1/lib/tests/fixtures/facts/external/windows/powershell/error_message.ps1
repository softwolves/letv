[Console]::Error.WriteLine('error message!')
Write 'foo=bar'
exit 0
