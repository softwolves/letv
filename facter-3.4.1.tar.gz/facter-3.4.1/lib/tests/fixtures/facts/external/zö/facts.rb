Facter.add "snowman_fact" do
  setcode { "olaf" }
end
