#!/usr/bin/env python
# coding=utf8
# Last modified: 
# Author: kevin
# Mail:  huangsicong@letv.com

import json
import re
import sys
import os
import re
import time
import subprocess

def cpu_discovery(filter):
    f=open('/proc/cpuinfo','r')
    cpu_list = []
    for line in f:
        if 'processor' in line:
            cpu = line.strip('\n').split(':')[1].split(' ')[1]
            #CPU_SEQ 为cpu的序号
            cpu_list += [{'{#CPU_SEQ}' : cpu}]

    print json.dumps({'data':cpu_list},sort_keys=True,indent=7,separators=(',',':'))

def fs_discovery_letv(filter):
    fs_list = []
    f = subprocess.Popen(["/bin/mount -l | awk ' { print $3,$5 }'"],stdout= subprocess.PIPE, shell=True)
    f.wait()
    for line in f.stdout:
        line = re.split('\s*',line)
        fs_name = line[0]
        if fs_name == '/letv':
            fs_list += [{'{#LETV}': fs_name}]

    print json.dumps({'data':fs_list},sort_keys=True,indent=7,separators=(',',':'))

def fs_discovery_sp(filter):
    fs_list = []
    f = subprocess.Popen(["/bin/mount -l | awk ' { print $3,$5 }'"],stdout= subprocess.PIPE, shell=True)
    f.wait()
    for line in f.stdout:
        line = re.split('\s*',line)
        fs_name = line[0]
	res = re.search(filter,fs_name)
	if res:
            fs_list += [{'{#%s}' %(filter): fs_name}]

    print json.dumps({'data':fs_list},sort_keys=True,indent=7,separators=(',',':'))

def fs_discovery_slot(filter):
    fs_list = []
    f = subprocess.Popen(["/bin/mount -l | awk ' { print $3,$5 }'"],stdout= subprocess.PIPE, shell=True)
    f.wait()
    for line in f.stdout:
        line = re.split('\s*',line)
        fs_name = line[0]
        if '/data/slot' in fs_name:
            fs_list += [{'{#SLOT}': fs_name}]

    print json.dumps({'data':fs_list},sort_keys=True,indent=7,separators=(',',':'))

def fs_discovery_fet(filter):
    fs_list = []
    f = subprocess.Popen(["/bin/mount -l | awk ' { print $3,$5 }'"],stdout= subprocess.PIPE, shell=True)
    f.wait()
    for line in f.stdout:
        line = re.split('\s*',line)
        fs_name = line[0]
        if fs_name == '/letv/fet':
            fs_list += [{'{#FET}': fs_name}]

    print json.dumps({'data':fs_list},sort_keys=True,indent=7,separators=(',',':'))

def fs_discovery_livemem(filter):
    fs_list = []
    f = subprocess.Popen(["/bin/mount -l | awk ' { print $3,$5 }'"],stdout= subprocess.PIPE, shell=True)
    f.wait()
    for line in f.stdout:
        line = re.split('\s*',line)
        fs_name = line[0]
        if fs_name == '/livemem':
            fs_list += [{'{#LIVEMEM}': fs_name}]

    print json.dumps({'data':fs_list},sort_keys=True,indent=7,separators=(',',':'))

def fs_discovery(filter):
    fs_list = []
    f = subprocess.Popen(["/bin/mount -l | awk ' { print $3,$5 }'"],stdout= subprocess.PIPE, shell=True)
    f.wait()
    filter_fs_type = ['sysfs','tmpfs','udev','devfs','devpts','proc','swap','binfmt_misc','iso9660']
    fs_list = []
    for line in f.stdout:
        line = re.split('\s*',line)
        fs_name = line[0]
        fs_type = line[1]
        res = re.search(filter,fs_name)
        if fs_type in filter_fs_type or res or '/data/slot' in fs_name: 
            continue
        fs_list += [{'{#FS_NAME}': fs_name}]
    print json.dumps({'data':fs_list},sort_keys=True,indent=7,separators=(',',':'))

def disk_discovery(filter):
    disk_list = []
    #f = os.popen("/usr/bin/iostat | sed -n '/Device/,$p' | egrep -v 'Device|^$' | awk '{ print $1 }' ")
    f = open('/proc/diskstats')
    for line in f:
        disk = line.strip().split()
        #res = re.search(filter,disk)
	fs_id = int(disk[0])
	fs_name = disk[2]
#	print fs_id,fs_name
        #m_iops = os.popen("grep '%s' /proc/diskstats" %(disk))
        #m_line = m_iops.readline()
        if fs_id == 8:
            disk_list += [{'{#DISK}': fs_name}]
    print json.dumps({'data':disk_list},sort_keys=True,indent=7,separators=(',',':'))

def net_speed(net):
    '''get net interface spped'''
    f_speed = os.popen("sudo /sbin/ethtool %s | sed -n '/Advertised pause frame use/{x;p};h'" %(net))
    f_line = f_speed.readline()
    f_line = f_line.strip('\t')
    speed = ''
    speed = f_line.split('base')[0].strip(' ')
    if speed.find('10') == -1:
        speed = ''
    return speed

def net_discovery_real(filter):
    net_list = []
    f = subprocess.Popen(["/sbin/ifconfig | grep 'Link encap:' |awk ' { print $1 } '"],stdout= subprocess.PIPE, shell=True )
    f.wait()
    for net in f.stdout:
        net = net.strip()
        speed = net_speed(net)
        res = re.search(filter,net)
        if speed == '' or res:
            continue
        net_list += [{'{#REAL}': net}]

    print json.dumps({'data':net_list},sort_keys=True,indent=7,separators=(',',':'))

def net_discovery_virtual(filter):
    net_list = []
    f = subprocess.Popen(["/sbin/ifconfig | grep 'Link encap:' |awk ' { print $1 } '"],stdout= subprocess.PIPE, shell=True )
    f.wait()
    for net in f.stdout:
        net = net.strip()
	net_overruns_f = os.popen("/sbin/ifconfig %s| grep 'overruns'" %(net))
	net_overruns = net_overruns_f.readline()
	net_overruns = net_overruns.strip('\t')
        res = re.search(filter,net)
        if net_overruns != '' and (not res):
            net_list += [{'{#VIRTUAL}': net}]

    print json.dumps({'data':net_list},sort_keys=True,indent=7,separators=(',',':'))

actions_list = {'cpu': cpu_discovery,'fs':fs_discovery,'disk':disk_discovery, \
        'net_r':net_discovery_real, 'net_v':net_discovery_virtual, 'livemem':fs_discovery_livemem, \
        'fet':fs_discovery_fet, 'letv':fs_discovery_letv , 'fs_sp': fs_discovery_sp,'slot':fs_discovery_slot}

if len(sys.argv) < 2:
    print 'no action specified'
    sys.exit()
elif len(sys.argv) == 2:
    action = sys.argv[1]
    filter = '^$'
elif len(sys.argv) >2:
    action = sys.argv[1]
    filter = sys.argv[2]
actions_list[action](filter)
