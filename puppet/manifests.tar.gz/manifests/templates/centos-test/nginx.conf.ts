error_log              127.0.0.1 error;
#error_log   /letv/fet/nginx_error.log crit;
worker_processes       64;
worker_rlimit_nofile   32768;
daemon on;
rtmp_config_file   /usr/local/etc/rtmp.conf;
user  root;

worker_rlimit_core 1024000000;
working_directory /home/lihongfu;

binary_version /lib/libudtp.so 0.0.27;
binary_version /lib/libffmux.so 0.3.13;


events {
    worker_connections 32768;
}

config_version letv/2013-04-22/2.87/letv;

#start add by lihongfu 2011-08-26
group_define video_on_demand 0-32;
group_define snmpband        33-33;
group_define gslb            34-36;
group_define iphone          37-49;
group_define test_speed      50 - 50;
group_define live       51-62;
#group_define timeshift  60-62;
#group_define mp4_slice 51-52;
#group_define slice 53-53;
#group_define iphone 53-60;
group_define test 63-63;

group $uri /snmpband snmpband hash;
group $uri /vod/v  gslb hash;
group $args test=1 test hash;
group $uri  letvabcdeasktf test_speed hash;
#group $args start=.*&end=.* mp4_slice hash;
#group $args begin  slice hash;
group $args tag=ios  iphone hash;
group $uri /video/ts iphone hash;

#group $args process_id=6[1-3] test hash;
#group $args process_id=5[1-2] mp4_slice random;
#group $args process_id=5[3-9] iphone hash;
#group $args process_id=4[6-9] live   hash;
#group $args process_id=50     live   hash;
#group $args process_id=60     iphone 6;
group $args process_id=63 test hash;
group $args process_id=5[1-9]     live   hash;
group $args process_id=6[0-2]     live   hash;
group $args process_id        video_on_demand  random;

group $uri  desc.xml          live hash;
group $uri  .dat              live hash;
group $uri  \.ts$             live hash;
group $uri  desc.m3u8         live hash;

group $args timeshift         live hash;
group $uri ^.*$ video_on_demand hash;
#end add by lihongfu 2011-08-26

conn_report iphone off;

check_status mem 50;
check_status load 5;
check_status wget /crossdomain.xml?process_id=0 60;
check_status wget /crossdomain.xml?process_id=1 60;
check_status wget /crossdomain.xml?process_id=2 60;
check_status wget /crossdomain.xml?process_id=3 60;
check_status wget /crossdomain.xml?process_id=4 60;
check_status wget /crossdomain.xml?process_id=5 60;
check_status wget /crossdomain.xml?process_id=6 60;
check_status wget /crossdomain.xml?process_id=7 60;
check_status wget /crossdomain.xml?process_id=8 60;
check_status wget /crossdomain.xml?process_id=9 60;
check_status wget /crossdomain.xml?process_id=10 60;
check_status wget /crossdomain.xml?process_id=11 60;
check_status wget /crossdomain.xml?process_id=12 60;
check_status wget /crossdomain.xml?process_id=13 60;
check_status wget /crossdomain.xml?process_id=14 60;
check_status wget /crossdomain.xml?process_id=15 60;
check_status wget /crossdomain.xml?process_id=16 60;
check_status wget /crossdomain.xml?process_id=17 60;
check_status wget /crossdomain.xml?process_id=18 60;
check_status wget /crossdomain.xml?process_id=19 60;
check_status wget /crossdomain.xml?process_id=20 60;
check_status wget /crossdomain.xml?process_id=21 60;
check_status wget /crossdomain.xml?process_id=22 60;
check_status wget /crossdomain.xml?process_id=23 60;
check_status wget /crossdomain.xml?process_id=24 60;
check_status wget /crossdomain.xml?process_id=25 60;
check_status wget /crossdomain.xml?process_id=26 60;
check_status wget /crossdomain.xml?process_id=27 60;
check_status wget /crossdomain.xml?process_id=28 60;
check_status wget /crossdomain.xml?process_id=29 60;
check_status wget /crossdomain.xml?process_id=30 60;
check_status wget /crossdomain.xml?process_id=31 60;
check_status wget /crossdomain.xml?process_id=32 60;
check_status wget /crossdomain.xml?process_id=33 60;
check_status wget /crossdomain.xml?process_id=34 60;
check_status wget /crossdomain.xml?process_id=35 60;
check_status wget /crossdomain.xml?process_id=36 60;
check_status wget /crossdomain.xml?process_id=37 60;
check_status wget /crossdomain.xml?process_id=38 60;
check_status wget /crossdomain.xml?process_id=39 60;
check_status wget /crossdomain.xml?process_id=40 60;
check_status wget /crossdomain.xml?process_id=41 60;
check_status wget /crossdomain.xml?process_id=42 60;
check_status wget /crossdomain.xml?process_id=43 60;
check_status wget /crossdomain.xml?process_id=44 60;
check_status wget /crossdomain.xml?process_id=45 60;
check_status wget /crossdomain.xml?process_id=46 60;
check_status wget /crossdomain.xml?process_id=47 60;
check_status wget /crossdomain.xml?process_id=48 60;
check_status wget /crossdomain.xml?process_id=49 60;
check_status wget /crossdomain.xml?process_id=50 60;
check_status wget /crossdomain.xml?process_id=51 60;
check_status wget /crossdomain.xml?process_id=52 60;
check_status wget /crossdomain.xml?process_id=53 60;
check_status wget /crossdomain.xml?process_id=54 60;
check_status wget /crossdomain.xml?process_id=55 60;
check_status wget /crossdomain.xml?process_id=56 60;
check_status wget /crossdomain.xml?process_id=57 60;
check_status wget /crossdomain.xml?process_id=58 60;
check_status wget /crossdomain.xml?process_id=59 60;
check_status wget /crossdomain.xml?process_id=60 60;
check_status wget /crossdomain.xml?process_id=61 60;
check_status wget /crossdomain.xml?process_id=62 60;
check_status wget /crossdomain.xml?process_id=63 60;


http {
    include            gslb_upstream.conf;
    include            nginx/mime.types;
    default_type       application/octet-stream;

    log_format cdntsd '$msec $status  $arg_tag $proxyed $bytes_sent $request_time'
                       ' "$log_for_ts" "$http_referer" "$http_user_agent" $remote_addr $host';
		
    log_format letvcdn '$server_addr $remote_addr [$time_local] "$log_for_ts" '
                       '$status $body_bytes_sent $request_time "$http_referer" '
                       '"$http_user_agent" "$http_x_forwarded_for" $host $proxyed';

    #access_log         /usr/local/letv/access.log cdntsd;
    #access_udplog      127.0.0.1 letvcdn;
    include access_log.conf;
    sendfile           on;
    tcp_nopush  on;
    sendfile_max_chunk 1m;
    keepalive_timeout  30;
    tcp_nodelay on;
    server_names_hash_bucket_size 128;
    client_header_buffer_size 128k;
    large_client_header_buffers 16 128k;
    recursive_error_pages on;
    resolver 60.28.199.196;
    root     /letv/fet;


    gst                on;
    gst_signature      uesless; # change this! for host on GSLB.
    gst_delay          5s;   
 

    server {
        listen         80 default;
        listen         443;
        #listen         25;
        listen         110;
        listen         1755;
        server_name    localhost;
        #resolver 60.28.199.196;
        #root     /letv/fet;

        client_header_timeout 10m;
        proxy_set_header host owninneragent;
        proxy_set_header X-IP $remote_addr;
        
#        proxy_buffering       off;
        proxy_connect_timeout 10;
        proxy_read_timeout    10;
        proxy_send_timeout    10;
        video_path  /letv/fet;
        video_length 10;
        m3u8_path   /letv/fet;
        include live.conf;

       location ~ \-mp4.ts$ {
           rewrite ^/(.*)-mp4.ts$ /$1.mp4 last;
       }

       location ~ \-flv.ts$ {
           rewrite ^/(.*)-flv.ts$ /$1.flv last;
       }

       location ~ \.m3u8$ {
           rewrite ^/(.*)\.m3u8$ /$1.$arg_video_type last;
       }

       location ~ ^/live/letvabcdeasktf {
           if ($arg_speednp = "1") {
               test_speed;
           }

           if ($arg_path = "0") { 
               test_speed; 
           }
  
           if ($arg_path = "") {
               test_speed; 
           }
         
           proxy_store off;
           proxy_pass http://$broadcast_proxy_ip$uri?$broadcast_proxy_args;
       }


       location ~ ^/letvabcdeasktf {
           test_speed;
       }


        location / {
            index  nofile;
        }


        location ~ ^/qihu360_NOT_FOUND/ {
               proxy_store on;
               add_header   Powered-By-Watchdog MISS-$hostname;
               rewrite ^/qihu360_NOT_FOUND/(.*) /$1 break;
               watchdog      on;
               proxy_pass http://coop.letv.com;
        }

        location ~ ^/[0-9]+/[0-9]+/[0-9]+/qihu360/ {
			expires           365d;
            root /letv/fet;
            rewrite ^/(.*)\.letv$ /$1.$arg_video_type last;
            
	    set $sec_ok "ok";
            secure_link_secret e1f5dcafad012f826734b;
            if ($secure_link2 != "ok") {
                set $sec_ok "not_ok";
            }

            if ($arg_tag = "watchdog") {
                set $sec_ok "ok";
            }

            if ( $sec_ok != "ok") {
                return 403;
            }
            if ( !-e $request_filename) {
                rewrite ^/(.*) /qihu360_NOT_FOUND/$1?sign=360 last;
            }
            include qihu.conf;
        }
         location ~ ^/video2/iphone  {
                rewrite ^/video2/(.*) /video/$1 break;
                first_vtime 10;
                second_vtime 10;
                ave_vtime 10;
                add_header Powered-By-Watchdog HIT-$hostname;
                expires           365d;
                video;
                break;
         }


         location ~ ^/video/iphone  {
                add_header Powered-By-Watchdog HIT-$hostname;
                expires           365d;
                ts_for_log tag=$arg_tag&playid=$arg_play_id;
                video;
                break;

        }

        location = /config_version {
            total_config_version;
        }

       location = /crossdomain.xml {
		      expires           365d;
          crossdomain;
       }

       location = /snmpband {
            http_snmp_band;
       }

         location ~ \.letv$ {
             rewrite ^/(.*)\.letv$ /$1.$arg_video_type last;
         }


         location = /m3u8_version {
               m3u8_version;
         }


         location @TSNP {
             add_header   Powered-By-Watchdog MISS-$hostname;
             watchdog      on;
             proxy_store off;
             if ($arg_proxy != "") {
                 proxy_pass http://$proxy_ip$uri;
             }

             if ($arg_proxy = "") {
                 proxy_pass  http://back;
             }
         }

         location ~ ^/.+/video/ {
             rewrite ^/.+/video/(.*) /video/$1?$decode_arg last;
         }

         location ~ ^/video/  {

            if ($ts_video_file_exist != "") {
                add_header Powered-By-Watchdog HIT-$hostname;
                expires           365d;
                video;
                break;
            }

            if ($ts_video_file_exist = "") {
                #add_header   Powered-By-Watchdog MISS-$hostname;
                error_page 502 = @TSNP;
                #set $gslbip g3.letv.com;
                #rewrite ^/video/ts-[0-9]+-[0-9]+-[0-9]+-[0-9]+/(.*)$ /$1 break;
                #watchdog      on;
                #proxy_pass   http://$gslbip;
                #proxy_pass http://g3.letv.com;
                #proxy_pass  http://back;
                return 502;
                #break;
           }

        }

###########################################################

        location ~ ^/MP4/ {
	#access_log /usr/local/letv/mp4.log letvcdn;
	limit_rate_after 5500k;
	set $limit_rate 240k;
	if ($request_uri ~ aa7f2e([0-9]+)){
	set $limit_rate         $1k;
	}
            root /letv/fet;
            include security.conf;
            set $letv_range "";
            if ( $http_range ) {
                set $letv_range "letv_range";
            }

            if ($arg_tag = "mobile") {
                set $letv_range "";
            }


            set $letv_ua "letv_p2p";
            if ( $http_user_agent ~* "msie") {
                set $letv_ua "not_letv_p2p";
            }

            set $letv_range_ua "$letv_range#_#$letv_ua";
            if ( $letv_range_ua = "letv_range#_#not_letv_p2p" ) {
                return 401;

            }
            internal;
            rewrite ^/MP4/(.*)$ /$1 ;

            add_header Powered-By-Watchdog HIT-$hostname;
            expires           365d;

            if ($arg_begin != "") {
                 mp4;
                 break;
            }
            break;

        }


        location ~ ^/FLV/  {
	    #access_log /usr/local/letv/flv.log letvcdn;
	    limit_rate_after 5000k;
	    set $limit_rate 240k;
	    if ($request_uri ~ aa7f2e([0-9]+)){
	    set $limit_rate         $1k;
	    }
            root /letv/fet;
	    include security.conf;
###########################################################
            set $letv_range "";
            if ( $http_range ) {
                set $letv_range "letv_range";
            }

            if ($arg_tag = "mobile") {
                set $letv_range "";
            }

            set $letv_ua "letv_p2p";
            if ( $http_user_agent ~* "msie") {
                set $letv_ua "not_letv_p2p";
            }

            set $letv_range_ua "$letv_range#_#$letv_ua";
            if ( $letv_range_ua = "letv_range#_#not_letv_p2p" ) {
                return 401;

            }
###########################################################
            internal;
            rewrite ^/FLV/(.*)$ /$1 ;
            add_header Powered-By-Watchdog HIT-$hostname;
            expires      365d;


            if ($arg_start_time != "") {
                 flv_mp4_streaming;
                 break;
            }
                
            if ($arg_begin != "") {
                 flv_mp4_streaming;
                 break;
            } 

           flv;
           break; 
        }


###########################################################
        location ~ ^/NginxStatus/ {
            access_log       off;
            stub_status      on;
            allow            127.0.0.1;
            allow            220.181.117.0/24;
            allow            211.151.82.0/24;
            allow            202.43.150.98/32;
            allow            119.57.39.0/24;
            allow            119.57.33.0/24;
            allow            220.181.117.0/24;
            allow            220.181.155.0/24;
            allow            220.181.153.0/24;
            allow            211.151.82.0/24;
            allow            115.182.51.0/24;
            allow            123.125.89.0/24;
            allow            123.126.32.0/24;
            allow            123.126.33.0/24;
            allow            60.28.199.0/24;
            allow            119.57.39.0/24;
            allow            119.57.33.0/24;
            allow            10.10.0.0/16;
            allow            10.57.0.0/16;
            deny             all;
        }

        location ~* ^/NOT_FOUND {
            include redirect.conf;

        }

        location ~* ^/snapimg/ {
            root /letv/fet;
            internal;
            set $action "snapimg/" ;
            set $CACHE_HIT "-";

            rewrite ^/snapimg/(.*)$ /$1 break;
            flv_mp4_snapimg;
        }




        location ~* ^/(.*)$ {

               if ($args ~* abtimeshift) {
                    rewrite ^/(.*)\/$ /timeshift/$1/$abshifttimeuri last;
                    rewrite ^/(.*)$   /timeshift/$1/$abshifttimeuri last;
               }

                if ($args ~* timeshift) {
                    rewrite ^/(.*)\/$ /timeshift/$1/$shifttimeuri last;
                    rewrite ^/(.*)$   /timeshift/$1/$shifttimeuri last;
                }


            if ( !-e $request_filename) {
                rewrite ^/(.*)$ /NOT_FOUND/$1 last;
            }

            if ( $arg_snaptm != "") {
                 rewrite ^/(.*)$ /snapimg/$1 last;
            }

               if ( $args ~* =ios ) {
                        rewrite ^/(.*)$ /video/iphone/$1 last;
                }


               if ( $args ~* m3u8=tvts  ) {
                      rewrite ^/(.*)$ /video2/iphone/$1?first_vtime=10&second_vtime=10&ave_vtime=10 last;
               }


               if ( $args ~* tag=tvts  ) {
                      rewrite ^/(.*)$ /video2/iphone/$1?first_vtime=10&second_vtime=10&ave_vtime=10 last;
               }


                if ( $args ~* tag=ios ) {
                        rewrite ^/(.*)$ /video/iphone/$1 last;
                }
            
               if ( $request_filename ~* "\.flv$") {
                        rewrite ^/(.*)$ /FLV/$1 last;
               }
            
               if ($request_filename ~* "\.mp4$") {
                         rewrite ^/(.*)$ /MP4/$1 last;
               }
                
        }

    }

#    include vhost.conf;

    #GSLB
    server {
        listen       80;
        server_name  e3.letvgslb.cn e3.letvgslb.com .g3.letv.cn .g3.letv.com;
        include      /usr/local/etc/hosts.conf;
        #resolver    60.28.199.196;
        #root        /letv/fet;
 
        location @PROXY_GSLB_NOT_FOUND {
            proxy_connect_timeout 5;
            proxy_read_timeout    5;
            proxy_send_timeout    5;
            proxy_set_header Host $host;
            proxy_pass_request_body on;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_pass http://$proxyHost$uri?$args&retry=0&code=$errorCode;
        }

        location = /crossdomain.xml {
            expires    365d;
            crossdomain;
        }

        location / {
             error_page 404 = @PROXY_GSLB_NOT_FOUND;
             load_balance;
        }
    }
}
