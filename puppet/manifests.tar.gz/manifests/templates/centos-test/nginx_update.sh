#!/bin/bash

PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin


nginx_md5="`cat /letv/soft/nginx/md5-nginx`"
if [ ! -f /usr/local/sbin/nginx ]
then
        touch /usr/local/sbin/nginx 
fi

download_addr1="220.181.155.10"
download_addr2="123.125.89.16"
download_addr3="115.182.94.72"
#download_addr3="115.182.63.202"
download_addr4="115.182.94.72"

hostname  |grep -iq cnc
if [ $? -eq 0 ]
then
        download_addr=$download_addr2
else
        hostname  |grep -iq ctc
        if [ $? -eq 0 ]
        then
                download_addr=$download_addr1
        else
                download_addr=$download_addr3
        fi

fi


real_nginx_md5="`md5sum /usr/local/sbin/nginx | awk '{print $1}'`"

if [ "$nginx_md5" != "$real_nginx_md5" ]
then
        rm -rf /usr/local/sbin/nginx_tmp 
        axel -a -o /usr/local/sbin/nginx_tmp http://$download_addr/nginx-test
        nginx_tmp_md5="`md5sum /usr/local/sbin/nginx_tmp | awk '{print $1}'`"
        if [ "$nginx_md5" = "$nginx_tmp_md5" ]
        then
                rm -rf /usr/local/sbin/nginx
                mv /usr/local/sbin/nginx_tmp /usr/local/sbin/nginx 
                chmod 755 /usr/local/sbin/nginx 
                #/usr/local/sbin/nginx -c /usr/local/etc/nginx.conf -s reload
		killall -9 nginx
		sleep 1
		killall -9 nginx
                sleep 1
		/usr/local/sbin/nginx -c /usr/local/etc/nginx.conf
        else
		rm -rf /usr/local/sbin/nginx
		axel -a -o /usr/local/sbin/nginx http://$download_addr4/nginx-test
                chmod 755 /usr/local/sbin/nginx 
                #/usr/local/sbin/nginx -c /usr/local/etc/nginx.conf -s reload
                killall -9 nginx
                sleep 1
                killall -9 nginx
                sleep 1
                /usr/local/sbin/nginx -c /usr/local/etc/nginx.conf

	fi
fi

md5sum /usr/local/sbin/nginx 2>&1|awk '{print $1}' >/letv/soft/nginx/md5-nginx
