#!/bin/bash
#Power by xwt
#Last edit date 2012-9-12
PATH=/sbin:/bin:/usr/sbin:/usr/bin:/usr/games:/usr/local/sbin:/usr/local/bin:/root/bin

nc -z -r 127.0.0.1 1935 >/dev/null

if [ $? -ne 0 ]
then
        killall -9 crtmpserver
        sleep 2
        killall -9 crtmpserver
        sleep 2
	sudo -u www /usr/local/sbin/crtmpserver /usr/local/etc/crtmpserver.lua
fi

md5sum /usr/local/sbin/crtmpserver |awk '{print $1}' >/usr/local/etc/md5-crtmpserver
md5sum /lib/libudtp.so.0 2>&1|awk '{print $1}' >/usr/local/etc/md5-libudtp
