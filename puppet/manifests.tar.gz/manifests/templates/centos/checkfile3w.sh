#!/bin/bash
cd /letv/all/
axel -o  /letv/all/3w http://123.125.89.86/3w
data=`date -d "yesterday" +"%Y%m%d"`
mv check1 check1_$data.log
#wget -O list1 http://60.28.199.162/list1
cat $1 | while read date 
do
echo "$date"
echo "==============="
url=`echo "${date}" |awk -F, '{print $1}'`
size=`echo "${date}" |awk -F, '{print $2}'`
#size=`echo "${date}" |awk -F, '{print $3}'`
#localsize=`curl -I http://127.0.0.1/${url}|grep Content-Length |awk '{print $2}'`
if [ -f /letv/fet/$url ] ;then
#localsize=`curl -I http://127.0.0.1/${url}|grep Content-Length |awk '{print $2}'`
localsize=`ls -l /letv/fet/$url |awk '{print $5}'`
else
echo "${url} No found ">> check1
continue
fi

lsize=`echo $localsize|tr -d '\r'`
#if [ "$lsize" == "" ] ;then
#echo "${url} No found ">> check1
#break
#continue
#elif [ "$lsize" != "$size" ];then
if [ "$localsize" != "$size" ];then
rm -rf /letv/fet/${url}
#curl -is "http://115.182.51.82:80/setfid?flag=0&file=$url"
echo "${url},${localsize} localfile Error">> check1
else
echo  "${url} localfile Correct">> check1
fi
done
