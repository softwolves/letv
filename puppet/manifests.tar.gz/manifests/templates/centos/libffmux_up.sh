#!/bin/bash
PATH=/sbin:/bin:/usr/sbin:/usr/bin:/usr/games:/usr/local/sbin:/usr/local/bin:/root/bin
uppath=/lib/
upfile=/lib/ffmux.tar.bz2
oldmd5=/letv/soft/nginx/oldmd5-ffu  
newmd5=/letv/soft/nginx/newmd5-ffu       
upmd5=/letv/soft/nginx/md5-ffu

cd $uppath 

upmd5_tmp=`cat $upmd5`
oldmd5_tmp=`cat $oldmd5`

if [ "$upmd5_tmp" != "`md5sum $upfile |awk '{print $1}'`"  ]
then
	rm -rf $upfile
fi

if [ "$upmd5_tmp" != "$oldmd5_tmp" ];then
	rm -rf $upfile
	axel -a -o $upfile http://<%= listserver %>/ffmux.tar.bz2
	md5sum "$upfile" |awk '{print $1}' > $newmd5
else
	exit 0
fi

newmd5_tmp=`cat $newmd5`
if [ "$newmd5_tmp" == "$upmd5_tmp" ] && [ "$newmd5_tmp" != "$oldmd5_tmp" ]  ;then
	killall -9 nginx
	sleep 1
	tar -jxf $upfile 
	killall -9 nginx
	ldconfig
	/usr/local/sbin/nginx -c /usr/local/etc/nginx.conf
	md5sum $upfile |awk '{print $1}' > $oldmd5
else
	md5sum $upfile |awk '{print $1}' > $oldmd5
	md5sum $upfile |awk '{print $1}' > $upmd5
exit 0
fi
