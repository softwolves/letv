#!/bin/bash

udpclient_md5="eae089d6bdbf66b61c847b2902972698"
real_udpclient_md5="`md5sum /usr/local/sbin/udpclient.linux |awk '{print $1}'`"
if [ "$udpclient_md5" != "$real_udpclient_md5" ]
then
	rm -rf /usr/local/sbin/udpclient.linux
	touch /usr/local/sbin/udpclient.linux
	wget -O /usr/local/sbin/udpclient.linux http://60.28.199.162/cdn/centosfile/udpclient.linux
	chmod 755 /usr/local/sbin/udpclient.linux
fi
