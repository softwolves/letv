#!/bin/bash
#axel -a http://<%= listserver %>/nginx
kernel=kernel-2.6.32-900.220.23.1.letv.el6.x86_64.rpm
kernelfi=http://115.182.51.149/pkgs/centos6/updates/kernel/kernel-firmware-2.6.32-900.220.23.1.letv.el6.x86_64.rpm
cd /tmp/
rm -rf kernel*
<%= cli1 %> http://<%= listserver %>/$kernel
<%= cli1 %> $kernelfi 
<%= cli2 %> http://<%= listserver %>/$kernel http://<%= listserver2 %>/$kernel
<%= cli2 %> $kernelfi 
rpm -Uvh kernel-firmware-2.6.32-900.220.23.1.letv.el6.x86_64.rpm
rpm -ivh $kernel


