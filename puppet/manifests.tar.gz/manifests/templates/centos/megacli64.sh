#!/bin/bash
#check Raid card vd and pd state
HOSTNAME=`/bin/hostname`
CARD=`megacli64  -adpallinfo -a0 | grep "Product Name" | cut -d ':' -f2`
VDSTATE1=`megacli64  -cfgdsply -aALL | grep "State"`
VDSTATE2=`megacli64  -AdpAllInfo -aALL | grep "Degraded"`
VDSTATE3=`megacli64  -AdpAllInfo -aALL | grep " Offline"`
VDSTATE4=`megacli64 -LDInfo -L0 -aALL |grep Strip`
VDSTATE5=`megacli64 -LDInfo -L1 -aALL |grep Strip`
PDSTATE1=`megacli64  -cfgdsply -aALL | grep "Online" | wc -l | sed 's/ //'`
PDSTATE2=`megacli64  -cfgdsply -aALL | grep "Rebuild" | wc -l | sed 's/ //'`
PDSTATE3=`megacli64  -AdpAllInfo -aALL | grep "Critical Disks"`
PDSTATE4=`megacli64  -AdpAllInfo -aALL | grep "Disks"`
PDSTATE5=`megacli64  -AdpAllInfo -aALL | grep "Virtual"`

echo "############# Host Information ##############"
echo "Host : $HOSTNAME"
echo "Raid Card : $CARD"
echo ''''
echo "############ Virtual Disk State #############"
echo "VD Number: $PDSTATE5"
echo "Virtual Disk $VDSTATE1"
echo "$VDSTATE2"
echo "$VDSTATE3"
echo "Virtual Disk 0 Strip Size："
echo "$VDSTATE4"
echo "Virtual Disk 1 Strip Size："
echo "$VDSTATE5"
echo ""

echo "############ VD Disk State ##################"
echo "Online Disk : $PDSTATE1"
echo "Rebuild Disk : $PDSTATE2"
echo "$PDSTATE3"
echo ""
echo "############ Physical Disks State #############"
echo "$PDSTATE4"

