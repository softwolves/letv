#!/bin/bash
uppath=/letv/soft/tools
upfile=/letv/soft/tools/cdntsd.jar
update=`date -d "yesterday" +"%Y%m%d"`
oldmd5=/letv/soft/tools/oldmd5-tsdjar  
newmd5=/letv/soft/tools/newmd5-tsdjar    
upmd5=/letv/soft/tools/md5-tsdjar
cd $uppath 
if [ -f /letv/soft/tools/cdntsd.jar ] ;then
md5sum cdntsd.jar |awk  '{print $1}' > $oldmd5
else
echo "aaa" > $oldmd5
fi

rm -rf cdntsd.jar.* 
tmp2=`cat $upmd5`
tmp3=`cat $oldmd5`

cd $uppath 
if [ $tmp2 != $tmp3 ];then
rm -rf cdntsd.*
axel -a http://117.121.54.74/cdntsd.jar
md5sum "$upfile" |awk '{print $1}' > $newmd5
else
exit 0
fi
md5sum cdntsd.jar |awk '{print $1}' > $oldmd5
md5sum cdntsd.jar |awk '{print $1}' > $upmd5
exit 0
fi
