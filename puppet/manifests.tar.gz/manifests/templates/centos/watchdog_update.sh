#!/bin/bash

PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin


stop_watchdog() {
        killall -9 watchdog
        sleep 2
        killall -9 watchdog
        sleep 1
        killall -9 watchdog
        sleep 1
        killall -9 watchdog
}

start_watchdog() {
        chmod 755 /usr/local/sbin/watchdog
        ulimit -c unlimited
        /usr/local/sbin/watchdog
}


watchdog_md5="`cat /letv/soft/watchdog/md5-watchdog `"
if [ ! -f /usr/local/sbin/watchdog ]
then
        touch /usr/local/sbin/watchdog 
fi

download_addr1="220.181.155.10"
download_addr2="123.125.89.16"
download_addr3="115.182.63.202"
download_addr4="115.182.94.72"

#wget http://115.182.94.72/storage/centos6/libxml2.so.2 -O /lib/libxml2.so.2 ;ldconfig
#chmod 755 /lib/libxml2.so.2

hostname  |grep -iq cnc
if [ $? -eq 0 ]
then
        download_addr=$download_addr2
else
        hostname  |grep -iq ctc
        if [ $? -eq 0 ]
        then
                download_addr=$download_addr1
        else
                download_addr=$download_addr3
        fi

fi

real_watchdog_md5="`md5sum /usr/local/sbin/watchdog | awk '{print $1}'`"

if [ "$watchdog_md5" != "$real_watchdog_md5" ]
then
        rm -rf /usr/local/sbin/watchdog_tmp
        axel -a -o /usr/local/sbin/watchdog_tmp http://$download_addr/watchdog
	watchdog_tmp_md5="`md5sum /usr/local/sbin/watchdog_tmp | awk '{print $1}'`"
	if [ "$watchdog_md5" = "$watchdog_tmp_md5" ]
	then
		stop_watchdog
		rm -rf /usr/local/sbin/watchdog
		mv /usr/local/sbin/watchdog_tmp /usr/local/sbin/watchdog
		start_watchdog
	else
		stop_watchdog
		rm -rf /usr/local/sbin/watchdog
                axel -a -o /usr/local/sbin/watchdog http://$download_addr4/watchdog
		start_watchdog
	fi
	
        #wget -O /lib/libevent-2.0.so.5 http://$download_addr3/libevent-2.0.so.5
#       wget -O /lib/libevent-2.0.so.5 http://$download_addr4/libevent-2.0.so.5
#       chmod 644 /lib/libevent-2.0.so.5
#       ldconfig
        sleep 2

	if [ ! -f /usr/local/sbin/watchdog ]
	then
		stop_watchdog
		rm -rf /usr/local/sbin/watchdog
	        #axel -a -o /usr/local/sbin/watchdog http://$download_addr3/watchdog
	        axel -a -o /usr/local/sbin/watchdog http://$download_addr4/watchdog
		start_watchdog
	else
		stop_watchdog
		start_watchdog
	fi

fi
md5sum /usr/local/sbin/watchdog 2>&1|awk '{print $1}' >/letv/soft/watchdog/md5-watchdog
