#!/bin/bash
cdntsd="/letv/soft/tools/cdntsd.jar"
logdate=`date '+%Y%m%d%H%M'`
logs_path="/tmp/"
cd $logs_path 
mv cnt_ppas.log rtmp${logdate}.log
cat rtmp${logdate}.log|awk '{print $2,$3,$10,"rtmp","HIT",$11,$12}' |sed 's/=/ /g'|awk '{print $2,$3","$5,$6,$7,$9,$11}'|awk -F "," '{sprintf("date -d \"%s\" +%%s", $1) | getline d; print   d".000",$2}' >rtmpbw
#统计bw
/usr/local/jdk1.6.0_33/bin/java  -classpath ${cdntsd} Demand3 ${logs_path}rtmpbw 300 0 ${logs_path}rtmpbwdata
sed -i '/allbw/d'  ${logs_path}rtmpbwdata
sed -i '/^$/d' ${logs_path}rtmpbwdata
rm -rf rtmp${logdate}.log
rm -rf rtmp201*
#数据上报
cat ${logs_path}rtmpbwdata |while read myline
do
        echo "$myline" |nc -w 10 117.121.54.21 8012
done

