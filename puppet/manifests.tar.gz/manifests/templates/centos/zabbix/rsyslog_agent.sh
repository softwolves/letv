#!/bin/bash
cd /usr/local/zabbix

tail -n1 /etc/rsyslog.conf|grep 5549 > /dev/null
if [ $? -eq 1 ]
  then
    wget -O rsyslog.conf http://115.182.51.13:8080/zabbix/rsyslog.conf
	if [ -s rsyslog.conf ] && [ `tail -n1 rsyslog.conf|grep -c 5549` -eq 1 ]
	  then
            cp /etc/rsyslog.conf /etc/rsyslog_old.conf
	    mv -f rsyslog.conf /etc/rsyslog.conf
            cat /dev/null > /tmp/rsyslog_md5sum.tmp
	fi
fi 

NUM_IP=`cat /usr/local/zabbix/conf/host.temp|wc -w`
if [ $NUM_IP -eq 3 ]
  then
     PROXY_IP=`cat /usr/local/zabbix/conf/host.temp|awk '{print $2}'`
     PROXY=`tail -n 1 /etc/rsyslog.conf |awk -F @@ '{print $2}' |awk -F : '{print $1}'`
  if [[ $PROXY_IP != $PROXY ]] && [[ $PROXY_IP != "" ]]
     then
     sed -i "s/$PROXY/$PROXY_IP/g" /etc/rsyslog.conf
  fi
fi

ps -ef |grep rsyslogd|grep -v grep > /dev/null
if [ $? -eq 1 ]
  then 
     /etc/init.d/rsyslog start
  else
     md5sum1=`md5sum /etc/rsyslog.conf|awk '{print $1}'`
     md5sum2=`cat /tmp/rsyslog_md5sum.tmp`
     defunct_pro=`ps -ef|grep rsyslogd | grep defunct | grep -v grep |wc -l`
     if [ $md5sum1 == $md5sum2 -a $defunct_pro -eq 0 ]
     then
 	exit
     else
        /etc/init.d/rsyslog restart
        echo $md5sum1  > /tmp/rsyslog_md5sum.tmp
     fi
fi
