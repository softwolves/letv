#!/bin/bash
#Power by xwt
#Last edit date 2011-12-7

nc -z -r 127.0.0.1 843 >/dev/null

if [ $? -ne 0 ]
then
	killall -9 flashShitD
	sleep 2
	killall -9 flashShitD
	/usr/local/sbin/flashShitD -f /usr/local/sbin/policy.xml
fi
