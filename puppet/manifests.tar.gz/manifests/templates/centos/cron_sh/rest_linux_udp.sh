#!/bin/bash

#Power by xwt
#Last edit date 2012-2-9

PATH=/usr/kerberos/sbin:/usr/kerberos/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin

curl --max-time 30 --retry 3  http://127.0.0.1:10091/version 

if [ $? -eq 0 ]
then 
			killall -9 Udtserv.bin
			sleep 2
			killall -9 Udtserv.bin
			sleep 1
		fi
	fi
fi
