#!/bin/bash
#ts_url=`tail -20000 /usr/local/letv/access.log  | awk '{print $9}' | grep -E '^/video/ts*'|awk -F'"' '{print $1}' | head -1`
ts_url=`tail -20000 /usr/local/letv/access.log  | awk -F'"|"' '{print $2}' | awk '{print $2}' | grep -E '^/video/ts*'|awk -F'"' '{print $1}' | head -1`
if [ ! -z $ts_url ];then
 wget -S --tries=2 -O /dev/null "http://127.0.0.1${ts_url}" >/dev/null 2>&1 
#echo $?
if [ $? != 0 ];then
#                        killall -9 nginx
#                        killall -9 nginx
#                        killall -9 nginx
#			bash /usr/local/etc/restart_centos6_nginx.sh
kill -9 $(ps aux | grep nginx | grep iphone | awk '{print $2,$3}'| awk '{if ($2>90)print $1}')

curl -o /dev/null "http://115.182.93.94/herbert_${ts_url}"

curl -o /dev/null "http://115.182.94.72/data_import/nginx_restart.php?ts_url=${ts_url}" 
fi
fi
