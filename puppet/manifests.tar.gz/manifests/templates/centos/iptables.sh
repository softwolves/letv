#!/bin/bash
#2012-05-20
IPT=/sbin/iptables
service iptables stop
