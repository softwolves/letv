#!/bin/bash

PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin

libudtp_md5="`cat /usr/local/etc/md5-libudtp`"

download_addr1="220.181.155.10"
download_addr2="123.125.89.16"
download_addr3="115.182.94.72/cdn/live/"
#download_addr3="115.182.63.202"

hostname  |grep -iq cnc
if [ $? -eq 0 ]
then
	download_addr=$download_addr2
else
	hostname  |grep -iq ctc
	if [ $? -eq 0 ]
	then
		download_addr=$download_addr1
	else
		download_addr=$download_addr3
	fi

fi


real_libudtp_md5="`md5sum /lib/libudtp.so.0 | awk '{print $1}'`"

if [ "$libudtp_md5" != "$real_libudtp_md5" ]
then
	rm -rf /lib/libudtp*
	wget -O /lib/libudtp.so.0 http://$download_addr/libudtp.so.0
	chmod 755 /lib/libudtp.so.0
	ln -s /lib/libudtp.so.0 /lib/libudtp.so
	ldconfig
	killall -9 nginx
	sleep 1
	killall -9 nginx
	sleep 1
	/usr/local/sbin/nginx -c /usr/local/etc/nginx.conf

fi

#chmod 755 /usr/local/sbin/crtmpserver
md5sum /lib/libudtp.so.0 2>&1| awk '{print $1}' >/usr/local/etc/md5-libudtp
