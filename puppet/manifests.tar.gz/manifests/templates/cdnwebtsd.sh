#!/bin/bash
cdntsd="/letv/soft/tools/cdntsd.jar"
nginxpid="/var/run/"
logs_path="/usr/local/letv/"
logdate=`date '+%Y%m%d%H%M'`
cd $logs_path
#日志滚动,拿出有用的数据
mv  access.log  access_${logdate}.log
kill -USR1 `cat ${nginxpid}nginx.pid`
sleep <%= tsdtime %> 
jcdate=`date -d '-1hour' '+%Y-%m-%d %H'`
jccdate=`date -d "${jcdate}" +%s `
jcdate1=`date '+%Y-%m-%d %H'`
jccdate1=`date -d "${jcdate1}" +%s `
perl -i -p -e 's/(.+ 1.101) (\s+"GET)/$1ts $2/g if /video\/ts/' ${logs_path}access_${logdate}.log
#sed -ri '/video\/ts/s/(.+ 1.10\w) (\s+"GET)/\1ts \2/g' ${logs_path}access_${logdate}.log
#sed -ri '/video\/ts/s/(.+ 1.102) (\s+"GET)/\1ts \2/g' ${logs_path}access_${logdate}.log
#sed -ri '/video\/ts/s/(.+ 1.103) (\s+"GET)/\1ts \2/g' ${logs_path}access_${logdate}.log
#sed -ri '/vtype=down/s/(.+ 3.30\w (\s+"GET)/\1d \2/g' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 3.302) (\s+"GET)/$1d $2/g if /vtype=down/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 1.101) (\s+"GET)/$1bf $2/g if /typeFrom=baofeng/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100172 $2/g if /sign=bcloud_100172/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100001 $2/g if /sign=bcloud_100001/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100132 $2/g if /sign=bcloud_100132/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100349 $2/g if /sign=bcloud_100349/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100388 $2/g if /sign=bcloud_100388/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100008 $2/g if /sign=bcloud_100008/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100099 $2/g if /sign=bcloud_100099/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100755 $2/g if /sign=bcloud_100755/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100004 $2/g if /sign=bcloud_100004/' ${logs_path}access_${logdate}.log
perl -i -p -e 's/(.+ 2.203) (\s+"GET)/$1b100115 $2/g if /sign=bcloud_100115/' ${logs_path}access_${logdate}.log
#sed -i '/typeFrom=baofeng/{s/1.101/1.103/g;}' ${logs_path}access_${logdate}.log
#perl -i -p -e 's/(.+ 3.301) (\s+"GET)/$1d $2/g if /vtype=down/' ${logs_path}access_${logdate}.log
#sed -ri '/vtype=down/s/(.+ 3.302 (\s+"GET)/\1d \2/g' ${logs_path}access_${logdate}.log
#sed -i '/vtype=down/{/3.302/3.302d/g;}' ${logs_path}access_${logdate}.log
sed -i '/vtype=down/{s/-.-/3\.320/g;}' ${logs_path}access_${logdate}.log
#sed -i '/playid=2/{s/3.301/3.301d/;}' ${logs_path}access_${logdate}.log
#sed -i '/playid=2/{s/3.302/3.302d/;}' ${logs_path}access_${logdate}.log
#sed -i '/playid=2/{s/3.303/3.303d/;}' ${logs_path}access_${logdate}.log
sed -i '/tag=gug/{s/-\.-/100\.10000/g;}' ${logs_path}access_${logdate}.log
sed -i '/tag=mobile/{s/-\.-/3\.320/g;}' ${logs_path}access_${logdate}.log
sed -i '/letv-web/{s/-\.-/100\.10000/g;}' ${logs_path}access_${logdate}.log
sed -i '/tag=live/{s/-\.-/10\.1000/g;}' ${logs_path}access_${logdate}.log
sed -i '/qihu360/{s/-\.-/102\.10201/g;}' ${logs_path}access_${logdate}.log
sed -i '/kingsoft/{/[[:space:]]\.[[:space:]]/ 102.10202 /g}' ${logs_path}access_${logdate}.log
sed -i '/kingsoft/{s/-\.-/102\.10202/g;}' ${logs_path}access_${logdate}.log
sed -i '/typeFrom=baofeng/{s/1.101bf/1.103/g;}' ${logs_path}access_${logdate}.log
sed -i '/muzhiwan/{s/-\.-/102\.10203/g;}' ${logs_path}access_${logdate}.log
sed -i 's/[[:space:]]\.[[:space:]]/ -.- /g' ${logs_path}access_${logdate}.log
sed -i 's/1\.-/1.101/g' ${logs_path}access_${logdate}.log
sed -i 's/2\.-/2.201/g' ${logs_path}access_${logdate}.log
sed -i 's/3\.-/3.301/g' ${logs_path}access_${logdate}.log
sed -i 's/4\.-/4.400/g' ${logs_path}access_${logdate}.log
sed -i 's/5\.-/5.500/g' ${logs_path}access_${logdate}.log
sed -i 's/6\.-/6.601/g' ${logs_path}access_${logdate}.log
sed -i 's/8\.-/8.800/g' ${logs_path}access_${logdate}.log
sed -i 's/9\.-/9.900/g' ${logs_path}access_${logdate}.log
sed  's/MISS/HIT/g' ${logs_path}access_${logdate}.log >${logs_path}access_${logdate}.log.tmp
#grep -v nginx_check_status /usr/local/letv/access_${logdate}.log|egrep -v "snmpband|config_version"|awk '{print $1,$2,$3,$4}'| awk '($2 ~/200|206|400|500|503|404/)' > ${logs_path}cdntsd
#grep -v nginx_check_status /usr/local/letv/access_${logdate}.log|egrep -v "snmpband|config_version"|awk '{print $1,$2,$3,$4,$8,$9}'|awk '($2 ~/200|206/)' > ${logs_path}cdntsdbw
grep -v nginx_check_status /usr/local/letv/access_${logdate}.log.tmp|egrep -v "snmpband|config_version"|awk '{print $1,$2,$7,$4,$5,$6}' > ${logs_path}cdntsdbw
sed -i 's/-\.-/other/g' ${logs_path}cdntsdbw
#sed -i 's/-/kstsqp/g' ${logs_path}kingsofttsbw
#所有统计数据统一输入
#grep -v nginx_check_status /usr/local/letv/access_${logdate}.log|awk '{print $1,$2,$3,$8,$9}'|sed 's/-/tagtsqp/g'| awk '($2 ~/200|206|400|500|503/)' > ${logs_path}cdntsd
#egrep -v "nginx_check_status|desc.xml|snmpband|vtype=mp4" /usr/local/letv/access_${logdate}.log|awk '($2 ~/20*/)'|awk '{print $1,$8,$9}'  > ${logs_path}webspeed 
#egrep -v "nginx_check_status|desc.xml|snmpband" /usr/local/letv/access_${logdate}.log|awk '($2 ~/20*/)'|awk '{print $1,$8,$9}'  > ${logs_path}webspeed 
sed -i "1 i$jccdate.000 200 3.301 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100172 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100001 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100132 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100388 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100349 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100008 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100099 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100755 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100004 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.203b100115 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 undown HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 3.301d HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 3.302d HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 3.303d HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 1.101 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 1.102 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 1.103 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 1.101ts HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 1.102ts HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 1.103ts HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 2.201 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 4.400 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 5.500 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 6.601 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 6.602 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 8.800 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 9.900 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 10.1000 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 11.1100 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 100.10000 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 102.10201 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 102.10202 HIT 118 0.052"  ${logs_path}cdntsdbw
sed -i "1 i$jccdate.000 200 102.10203 HIT 118 0.052"  ${logs_path}cdntsdbw

tar czvf  access_${logdate}.tar.gz  access_${logdate}.log
rm -rf  access_${logdate}.log
find . -name "access_*.gz"   -mtime +2 -exec rm  {} \;
find . -name "access_*.*.tmp"  -exec rm  {} \;
#数据处理
#/usr/local/jdk1.6.0_33/bin/java  -classpath ${cdntsd}  Main ${logs_path}cdntsd 300 0  ${logs_path}tsdbdata 
#/usr/local/jdk1.6.0_33/bin/java  -classpath ${cdntsd}  Speed ${logs_path}webspeed 299 0 ${logs_path}tsdspeed  
#/usr/local/jdk1.6.0_33/bin/java  -classpath ${cdntsd}  Speed ${logs_path}webspeed 300 0,100,200,500,1000,2000,3000 ${logs_path}tsdspeed  
/usr/local/jdk1.6.0_33/bin/java  -classpath ${cdntsd} Demand3 ${logs_path}cdntsdbw 300 0 ${logs_path}cdntsdbwdata
#/usr/local/jdk1.6.0_33/bin/java  -classpath ${cdntsd} Demand3 ${logs_path}kingsofttsbw 300 0 ${logs_path}kingsofttsbwdata
#/usr/local/jdk1.6.0_33/bin/java  -classpath ${cdntsd} Demand4 ${logs_path}cdntsdbw 300 qihu360,kingsoft ${logs_path}cdntsdtfdata
#/usr/local/jdk1.6.0_33/bin/java  -classpath ${cdntsd} Demand3 ${logs_path}uaycbw 300 0 ${logs_path}uaycbwdata
sed -i '/^$/d' ${logs_path}cdntsdbwdata
sed -i '/'$jccdate1'/d' ${logs_path}cdntsdbwdata
#数据上报
#cat ${logs_path}tsdbdata|while read myline
#do
#	echo "$myline" |nc -w 10 117.121.54.21 <%= tsdport %>
#done

cat ${logs_path}cdntsdbwdata|while read myline
do
#        echo "$myline" |nc -w 30 117.121.54.21   8012 
        echo "$myline" |nc -w 30 117.121.54.21 <%= tsdport %>
done

