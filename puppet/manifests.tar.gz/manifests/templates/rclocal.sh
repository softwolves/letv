#!/bin/bash
blockdev="`cat /etc/rc.local |grep blockdev`"
if [ $? -eq 0 ]
then
echo "blockdev 参数存在"
else
mountd=` mount|grep fet |awk '{print $1}'`
sed -i "6 a/sbin/blockdev --setra 1024 ${mountd}" /etc/rc.local
eco 1024 > /sys/block/sdb/queue/read_ahead_kb
eco 1024 > /sys/block/sda/queue/read_ahead_kb
echo "blockdev 添加"
fi

cat /etc/rc.local >/tmp/rc.local
awk '{if ($0!=line) print;line=$0}' /tmp/rc.local  >/etc/rc.local

