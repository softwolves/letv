#!/bin/bash
#2012-05-20
IPT=/sbin/iptables
service iptables stop
$IPT -A INPUT -p tcp -m tcp --dport 135 --tcp-flags FIN,SYN,RST,ACK SYN -m connlimit --connlimit-above 10 --connlimit-mask 32 -j REJECT --reject-with tcp-reset
$IPT -A INPUT -p tcp -m tcp --dport 1935 --tcp-flags FIN,SYN,RST,ACK SYN -m connlimit --connlimit-above 1024 --connlimit-mask 32 -j REJECT --reject-with tcp-reset
$IPT -A INPUT -p tcp -m tcp --dport 443 --tcp-flags FIN,SYN,RST,ACK SYN -m connlimit --connlimit-above 1024 --connlimit-mask 32 -j REJECT --reject-with tcp-reset
$IPT -A INPUT -p tcp -m tcp --dport 25 --tcp-flags FIN,SYN,RST,ACK SYN -m connlimit --connlimit-above 1024 --connlimit-mask 32 -j REJECT --reject-with tcp-reset
$IPT -A INPUT -p tcp -m tcp --dport 110 --tcp-flags FIN,SYN,RST,ACK SYN -m connlimit --connlimit-above 1024 --connlimit-mask 32 -j REJECT --reject-with tcp-reset
$IPT -A INPUT -p tcp -m tcp --dport 1755 --tcp-flags FIN,SYN,RST,ACK SYN -m connlimit --connlimit-above 1024 --connlimit-mask 32 -j REJECT --reject-with tcp-reset
$IPT -A INPUT -p tcp -m tcp --dport 22 --tcp-flags FIN,SYN,RST,ACK SYN -m connlimit --connlimit-above 10 --connlimit-mask 32 -j REJECT --reject-with tcp-reset
$IPT -A INPUT -p tcp -m tcp --dport 80 --tcp-flags FIN,SYN,RST,ACK SYN -m connlimit --connlimit-above 1024 --connlimit-mask 32 -j REJECT --reject-with tcp-reset 
