require 'puppet/application/indirection_base'

class Puppet::Application::Status < Puppet::Application::IndirectionBase
end
