require 'puppet/application/face_base'
require 'puppet/face'

class Puppet::Application::Epp < Puppet::Application::FaceBase
end
