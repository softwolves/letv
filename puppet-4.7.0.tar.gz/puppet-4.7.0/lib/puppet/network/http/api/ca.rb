module Puppet::Network::HTTP::API::CA
end
