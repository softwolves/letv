module Puppet::Network::HTTP::API::Master
end
