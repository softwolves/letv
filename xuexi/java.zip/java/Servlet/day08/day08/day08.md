# cookie和session的作用
![](1.png)

# cookie
![](2.png)

# session
![](3.png)

# 退出
![](4.png)