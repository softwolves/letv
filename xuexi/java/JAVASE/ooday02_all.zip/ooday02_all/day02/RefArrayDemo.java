package oo.day02;
//���������������ʾ
public class RefArrayDemo {
	public static void main(String[] args) {
		/*
		Cell[] cells = new Cell[4]; //����Cell�������
		cells[0] = new Cell(2,5); //����Cell����
		cells[1] = new Cell(3,6);
		cells[2] = new Cell(4,7);
		cells[3] = new Cell(5,8);
		*/
		
		/*
		Cell[] cells = new Cell[]{
			new Cell(2,5),
			new Cell(3,6),
			new Cell(4,7),
			new Cell(5,8)
		};
		*/
		
		/*
		int[][] arr = new int[3][];
		arr[0] = new int[2];
		arr[1] = new int[3];
		arr[2] = new int[2];
		arr[1][0] = 100;
		*/
		
		/*
		int[][] arr = new int[3][4]; //3��4��
		for(int i=0;i<arr.length;i++){
			for(int j=0;j<arr[i].length;j++){
				arr[i][j] = 100;
			}
		}
		*/
	}
}


















