# Struts2

## Spring + Struts2

Struts2 提供了 spring 整合插件 struts2-spring-plugin.jar

只要将这个插件添加到/WEB-INF/lib 文件夹中，就会自动将spring整合到Struts2. 整合以后Struts2 的Action对象将由Spring容器创建

![](spring-plugin.png)

### 1. 手工整合

1. 分别到Spring和Struts2网站下载jar包
2. 将jar包复制到/WEB-INF/lib 文件夹中
3. 修改web.xml文件添加Spring容器初始化监听器
4. 添加Spring配置文件。

> 提示： 这个整合过程过于繁琐，请同学自行实验，正是这个整合过程非常繁琐，才能体现Maven这种自动化工具的优点。

### 2. 利用Maven整合

1. 创建Maven项目，导入Struts2组件，并且配置struts.xml和web.xml
	- `<dependency>`
  	- `	<groupId>org.apache.struts</groupId>`
  	- `	<artifactId>struts2-core</artifactId>`
  	- `	<version>2.3.8</version>`
  	- `</dependency>`
	- 配置struts.xml和web.xml 请参考day01.html
2. 找到struts2-spring组件坐标添加到Struts2项目的pom.xml，然后保存
	- `<dependency>`
  	- `	<groupId>org.apache.struts</groupId>`
  	- `	<artifactId>struts2-spring-plugin</artifactId>`
  	- `	<version>2.3.8</version>`
  	- `</dependency>`
	- 注意：插件版本必须与 Struts2 的版本必须一致！！！
	- Maven会自动导入插件依赖的Spring包。**这是Maven最便捷的特点**。
3. 配置web.xml，利用Spring提供的监听器在Web容器启动时候初始化Spring容器。
	- `<listener>`
  	- `	<listener-class>`
  	- `		org.springframework.web.context.ContextLoaderListener`
  	- `	</listener-class>`
  	- `</listener>`
  	- `<context-param>`
  	- `	<param-name>contextConfigLocation</param-name>`
  	- `	<param-value>classpath:spring-*.xml</param-value>`
  	- `</context-param>`
	- 其中context-param用于指定Spring配置文件的存储位置
4. 创建Spring配置文件： spring-context.xml 
	- 注意这个配置文件要与 Spring版本配合，版本不能错误。
5. 启动容器进行测试。

参考代码：

pom.xml(片段):

	<dependencies>
	  	<dependency>
	  		<groupId>org.apache.struts</groupId>
	  		<artifactId>struts2-core</artifactId>
	  		<version>2.3.8</version>
	  	</dependency>
	  	<dependency>
	  		<groupId>org.apache.struts</groupId>
	  		<artifactId>struts2-spring-plugin</artifactId>
	  		<version>2.3.8</version>
	  	</dependency>
	</dependencies>

web.xml 片段：

	<!-- 配置 Listener 用于初始化Spring容器  -->
	<!-- 在Web容器启动时候自动初始化Spring容器-->
	<listener>
	  	<listener-class>
	  	org.springframework.web.context.ContextLoaderListener
	  	</listener-class>
	</listener>
	<!-- 配置Spring配置文件的位置 -->
	<context-param>
	  	<param-name>contextConfigLocation</param-name>
	  	<param-value>classpath:spring-*.xml</param-value>
	</context-param>
	
	<!-- Struts2 主控制器配置 -->
	<filter>
	  	<filter-name>mvc</filter-name>
	  	<filter-class>
	org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter
	  	</filter-class>
	</filter>
	<filter-mapping>
	  	<filter-name>mvc</filter-name>
	  	<url-pattern>/*</url-pattern>
	</filter-mapping>
 
struts.xml:

	<?xml version="1.0" encoding="UTF-8"?>
	<!DOCTYPE struts PUBLIC
		"-//Apache Software Foundation//DTD Struts Configuration 2.3//EN"
		"http://struts.apache.org/dtds/struts-2.3.dtd">
	<struts>
	</struts>

spring-context.xml:

	<?xml version="1.0" encoding="UTF-8"?>
	<beans xmlns="http://www.springframework.org/schema/beans"
		xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:context="http://www.springframework.org/schema/context"
		xmlns:jdbc="http://www.springframework.org/schema/jdbc" xmlns:jee="http://www.springframework.org/schema/jee"
		xmlns:tx="http://www.springframework.org/schema/tx" xmlns:aop="http://www.springframework.org/schema/aop"
		xmlns:mvc="http://www.springframework.org/schema/mvc" xmlns:util="http://www.springframework.org/schema/util"
		xmlns:jpa="http://www.springframework.org/schema/data/jpa"
		xsi:schemaLocation="
			http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.0.xsd
			http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-3.0.xsd
			http://www.springframework.org/schema/jdbc http://www.springframework.org/schema/jdbc/spring-jdbc-3.0.xsd
			http://www.springframework.org/schema/jee http://www.springframework.org/schema/jee/spring-jee-3.0.xsd
			http://www.springframework.org/schema/tx http://www.springframework.org/schema/tx/spring-tx-3.0.xsd
			http://www.springframework.org/schema/data/jpa http://www.springframework.org/schema/data/jpa/spring-jpa-1.3.xsd
			http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop-3.0.xsd
			http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc-3.0.xsd
			http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util-3.0.xsd">
	
	</beans>

### 3. 编写测试案例测试整合结果

1. 在Spring配置文件中添加组件扫描
2. 添加控制器类，并且在类上添加注解
3. 在Struts2 配置文件中添加控制配置，其中class属性引用Spring的Bean ID
4. 添加测试用的视图JSP
5. 测试

spring-context.xml (片段):

	<context:component-scan	base-package="com.tedu"/>

HelloAction.class

	@Controller
	public class HelloAction {
		
		@Resource
		private DemoService demoService;
		
		public String execute(){
			demoService.hello();
			System.out.println("Hello World!"); 
			return "success";
		}
	}

DemoService.java

	@Service
	public class DemoService {
		public void hello(){
			System.out.println("Hello!");
		}
	}

msg.jsp: 

	<%@ page language="java"
	  	contentType="text/html; charset=UTF-8"
	    pageEncoding="UTF-8"%>
	<!DOCTYPE html>
	<html>
		<head>
			<meta charset="UTF-8">
			<title>Insert title here</title>
		</head>
		<body>
			<h1>OK!</h1>
		</body>
	</html>

 
struts.xml (局部):

	<package name="test" namespace="/test"
		extends="struts-default">
		<!-- 在有了Spring plugin 以后，action
		的class属性就可以使用Spring组件的ID了 -->
		<action name="hello" 
			class="helloAction">
			<result name="success">
				/WEB-INF/msg.jsp
			</result>
		</action> 
	</package>

## Result 常用类型

Struts2 支持多种Result类型，其中常用的有：
1. dispatcher 转发
2. redirectAction 重定向到 其他Action
3. stream 流：用于处理图片或者下载
4. json：用于处理ajax请求

> 转发类型是在Struts的主配置文件中定义 struts-default.xml
> json: 在struts2-json-plugin 插件中定义

### dispatcher 转发

是默认的Result， 也是最常用的类型。

### redirectAction 重定向到 其他Action

用于处理重定向结果： 详细语法请参考API手册 org.apache.struts2.dispatcher.ServletActionRedirectResult

使用方法：

DemoAction.java

	@Controller
	public class DemoAction {
		public String execute(){
			System.out.println("Demo");
			return "error";
		}
	}

struts.xml(局部)：

	<action name="hello" 
		class="helloAction">
		<result name="success">
			/WEB-INF/msg.jsp
		</result>
	</action> 
	<!-- 测试重定向 -->
	<action name="demo"
		class="demoAction">
		<result name="error" 
			type="redirectAction">
			hello
		</result>	
	</action>

如上代码在执行期间如果请求/demo.action 将被重定向到 /hello.action.

### stream 流result：用于处理图片或者下载

stream result用于处理图片或者下载，具体语法请参考： org.apache.struts2.dispatcher.StreamResult

关键语法：

	 <result name="success" type="stream">
	   <param name="contentType">image/jpeg</param>
	   <param name="inputName">imageStream</param>
	   <param name="contentDisposition">attachment;filename="document.pdf"</param>
	   <param name="bufferSize">1024</param>
	 </result>

说明：
- contentType： 定义媒体类型： image/png  等
- inputName： 必须是一个inputStream类型的流，用于获取发送到客户端的字节数据。如果是图片就是图片编码以后的字节流。
- contentDisposition： 可选参数，如果使用就可以强制下载保存
- bufferSize：可选参数，指定缓存区大小

案例：号码码图片的Action

CodeAction.java :

	@Controller
	public class CodeAction {
		
		public InputStream png;
		
		public String execute(){
			//生成图片流， 放到png中
			BufferedImage img = new BufferedImage(
				100, 38, BufferedImage.TYPE_3BYTE_BGR);
			//背景麻点
			for(int x=0;x<img.getWidth();x++){
				for(int y=0;y<img.getHeight();y++){
					int color = 
						(int)(Math.random()*0xffffff);
					img.setRGB(x, y, color);
				}
			}
			Graphics2D g = img.createGraphics();
			int color = 
				(int)(Math.random()*0xffffff);
			g.setColor(new Color(color));
			Font font=new Font(Font.SANS_SERIF,
					Font.BOLD, 30);
			g.setFont(font);
			//绘制编码
			g.drawString("3415", 10, 30);
			for(int i=0; i<5; i++){
				color = 
					(int)(Math.random()*0xffffff);
				g.setColor(new Color(color));
				int x1=(int)(Math.random()*100);
				int x2=(int)(Math.random()*100);
				int y1=(int)(Math.random()*38);
				int y2=(int)(Math.random()*38);
				g.drawLine(x1, y1, x2, y2);
			}
			
			ByteArrayOutputStream out =
				new ByteArrayOutputStream();
			try{
			//把图片对象编码为byte数组
				ImageIO.write(img, "png", out);
				out.close();
			}catch(IOException e){
				e.printStackTrace();
				throw new RuntimeException(e);
			}
			byte[] data=out.toByteArray();
			png = new ByteArrayInputStream(data);
			return "success";
		}
	}


struts.xml(局部)

	<action name="code"
		class="codeAction">
		<result name="success"
			type="stream">
				<param name="contentType">image/png</param>
				<!-- png是Action类中的bean属性，类型是InputStream -->				
				<param name="inputName">png</param>
		</result>
	</action>























