package com.tedu.web;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;

@Controller
public class JsonAction {
	private int id;
	public int getId() {
		return id;
	}
	private String message;
	public String getMessage() {
		return message;
	}
	//用于保存，向用户发送的JSON数据
	private Map<String, Object> value =
		new HashMap<String, Object>();
	public Map<String, Object> getValue() {
		return value;
	}
	public String execute(){
		value.put("name", "Tom");
		value.put("age", 100);
		value.put("message", "你吃了吗？");
		value.put("error", "吃到吐！");
		//....
		id = 100;
		message="Hello!";
		return "success";
	}
}




