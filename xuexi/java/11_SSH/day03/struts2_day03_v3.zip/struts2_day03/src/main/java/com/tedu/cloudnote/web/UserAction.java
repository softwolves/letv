package com.tedu.cloudnote.web;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.interceptor.SessionAware;
import org.springframework.stereotype.Controller;

import com.tedu.cloudnote.entity.User;
import com.tedu.cloudnote.service.UserService;
import com.tedu.cloudnote.util.NoteResult;

@Controller
public class UserAction 
	implements SessionAware {
	@Resource
	private UserService userService;
	
	private Map<String, Object> session;
	public void setSession(
		Map<String, Object> session) {
		this.session=session;
	}
	
	private String username;
	private String password;
	public void setPassword(String password) {
		this.password = password;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	NoteResult result;
	public NoteResult getResult() {
		return result;
	}
	
	public String login(){
		NoteResult result = 
				userService.checkLogin(
				username, password);
		this.result=result;
		if(result.getStatus()==0){
			User user=(User)result.getData();
			session.put("loginUser", user);
		}
		return "success";
	}
}





