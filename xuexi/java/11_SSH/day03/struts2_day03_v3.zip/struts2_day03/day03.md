# Struts

## 值栈 ValueStack

1. 从控制器向页面传输值的缓存区
2. ValueStack 包含当前环境相关的全部 对象
	- request
	- session
	- application 等
3. ValueStack 包含两个区域
	- root: 一个List（栈）存储值  
	- context: 一个区域是Map存储环境相关的全部 对象  

> 提示： 在Struts2中ValueStack是软件的消息中心的作用。软件的数据和相关环境信息都缓存在这个对象中。其作用于JSP中的 pageContext 类似。

> JSP 页面中使用 <s:debug/> 标签可以展示 ValueStack 的内容

## OGNL 表达式

OGNL 可以在网页 struts 标签中使用，在Struts2中用于读写ValueStack的数据。

1. 读取root区域数据
	- 从栈顶到栈底逐一搜索 Bean 属性，找到属性就输出
2. 读写 context 区域使用 #key 的方式查找
	- #session.loginName

> 提示：OGNL与ValueStack配合可以从控制器向页面传递数据。

## ValueStack与EL

Struts2 中的拦截了EL表达式，使其从ValueStack中获取数据，也就是说使用EL就可以很好的访问ValueStack.

案例：

DemoAction.java
	
	@Controller
	public class DemoAction {
		
		String message;
		public String getMessage() {
			return message;
		}
		
		public String test(){
			ActionContext context = 
				ActionContext.getContext();
			ValueStack stack=context.getValueStack();
			
	 		Person p = new Person(
					1, "Jerry", "Hello Jerry");
			//将数据添加到值栈中			
			stack.push(p); 
			
			context.getSession()
				.put("loginName", "Robin");
			
			message = "demo";
			System.out.println(
				"Demo Action test()");
			return "success";
		}
	}

Person.class

	public class Person {
		int id;
		String pname;
		String message;
		public Person() {
		}
		
		public Person(int id, String pname, String message) {
			super();
			this.id = id;
			this.pname = pname;
			this.message = message;
		}
	
	
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getPname() {
			return pname;
		}
		public void setPname(String pname) {
			this.pname = pname;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
	}

struts.xml(局部)

	<package name="test"
		namespace="/test"
		extends="json-default">
		<action name="demo"
			class="demoAction"
			method="test">
			<result name="success">
				/WEB-INF/msg.jsp
			</result>
		</action>
	</package>

msg.jsp

	<%@ page language="java" 
		contentType="text/html; charset=UTF-8"
	    pageEncoding="UTF-8"%>
	<!-- 引入struts2 标签库 -->
	<%@taglib prefix="s" uri="/struts-tags" %>
	<!DOCTYPE html>
	<html>
	<head>
	<meta charset="UTF-8">
	<title></title>
	</head>
	<body>
		<h1>test</h1>
		<!-- 利用OGNL表达式读取值栈中的数据 -->
		<s:property value="message"/> <br>
		<s:property value="#session.loginName"/><br>
		<!-- 利用EL表达式读取值栈中的数据 -->
		${message} <br>
		${loginName} 
		<!-- s:debug 标签可以输出 ValueStack 中的数据 -->
		<s:debug></s:debug>
	</body>
	</html>



