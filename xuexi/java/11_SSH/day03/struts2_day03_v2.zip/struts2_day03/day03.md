# Struts

## 值栈 ValueStack

1. 从控制器向页面传输值的缓存区
2. ValueStack 包含当前环境相关的全部 对象
	- request
	- session
	- application 等
3. ValueStack 包含两个区域
	- root: 一个List（栈）存储值  
	- context: 一个区域是Map存储环境相关的全部 对象  

> 提示： 在Struts2中ValueStack是软件的消息中心的作用。软件的数据和相关环境信息都缓存在这个对象中。其作用于JSP中的 pageContext 类似。

> JSP 页面中使用 <s:debug/> 标签可以展示 ValueStack 的内容

## OGNL 表达式

OGNL 可以在网页 struts 标签中使用，在Struts2中用于读写ValueStack的数据。

1. 读取root区域数据
	- 从栈顶到栈底逐一搜索 Bean 属性，找到属性就输出
2. 读写 context 区域使用 #key 的方式查找
	- #session.loginName

> 提示：OGNL与ValueStack配合可以从控制器向页面传递数据。

## ValueStack与EL

Struts2 中的拦截了EL表达式，使其从ValueStack中获取数据，也就是说使用EL就可以很好的访问ValueStack.

案例：




