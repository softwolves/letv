# WEB应用的演变
## 规律
1. 从单机向网络演变
2. 从CS向BS演变

## 解释
### CS(Client Server)
客户端服务器程序，即客户端需要单独开发和安装

### BS(Browser Server)
浏览器服务器程序，即使用浏览器充当客户端

# Servlet
## 服务器如何给浏览器发送网页？
### 静态网页
- 新闻页、百度百科
- 服务器保存一份HTML，发送给浏览器即可

### 动态网页
- 淘宝页、微博
- 服务器保存一个组件，动态拼一个HTML发送给浏览器
- 在Java中该组件就是Servlet

> 组件就是满足规范的对象

## Servlet特征
- 部署在服务器上
- 可以用来动态拼资源(HTML/img)，即处理HTTP协议
- 必须满足Sun的规范

> 部署就是拷贝的术语

## 什么是Servlet
Servlet是Sun推出的，
用来在服务器端处理HTTP协议的组件

# 服务器
## 名称
- Java服务器
- WEB服务器
- Java WEB服务器
- Servlet容器

## 本质
- 是一个可以运行Java项目的软件
- 和浏览器平级

## 举例
- Tomcat
- JBoss
- WebLogic
- WebShpere

# Tomcat的使用
## 一、直接使用(上线时)
### 1.下载及安装
- 在Tomcat官网下载压缩包
- 绿色版解压缩后可用
> 学生机上已经安装好了/tts9/apache-tomcat-7

### 2.配置环境变量
- 配置JAVA_HOME
> 学生机上已经配置好了

### 3.启动Tomcat
- Linux：打开/tomcat/bin，终端输入./startup.sh
- Windows：打开/tomcat/bin，双击startup.bat
> 加权限：chmod +x *sh

### 4.访问Tomcat
- 在浏览器上访问: http://localhost:8080
- 看到一只猫着代表成功了

### 5.关闭Tomcat
- Linux：打开/tomcat/bin，终端输入./shutdown.sh
- windows：打开/tomcat/bin，双击shutdown.bat

## 二、用Eclipse运行Tomcat(开发时)
- 参考http://doc.tedu.cn/tomcat

## 端口被占用问题
### 错误信息
- Address already in use, JVM_BIND 8080

### 重复启动Tomcat
- 强制关闭Tomcat，即手动shutdown

### 其他软件占用端口(Oracle)
- 解决方案：修改Tomcat端口
- 修改/tomcat/conf/server.xml，65行port="8080"
- 修改/servers/server.xml，和上面文件一样

# Servlet开发步骤
## 1.创建WEB项目
- WEB目录：/webapp/WEB-INF/web.xml

## 2.导入jar包
- 通过maven搜索javaee导入
- 使用Tomcat自带的javaee包
> 右键项目->properties->targeted runtime->勾选tomcat

![](1.png)