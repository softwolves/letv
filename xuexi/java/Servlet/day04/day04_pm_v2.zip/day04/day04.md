# ServletConfig和ServletContext
![](1.png)

# Servlet5中的对象
![](2.png)

# HttpServlet的结构
![](3.png)

# Servlet线程安全问题
![](4.png)