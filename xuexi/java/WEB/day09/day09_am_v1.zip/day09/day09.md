# 自定义对象
## 1.直接量(JSON)
- var stu = {"name":"zhangsan","age":25};
- {}表示对象，内含键值对
- key一般是字符串，value可以是任意类型的数据
- 简单

## 2.构造器
### 2.1内置构造器
- new Date()
- new RegExp()
- new Function()
- new Object()

### 2.2自定义构造器

> JS中用来new的函数就是构造器
