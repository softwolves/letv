package annotation;
/**
 * 
 * 自定义注解
 */
public @interface MyBatisRepository {

}
