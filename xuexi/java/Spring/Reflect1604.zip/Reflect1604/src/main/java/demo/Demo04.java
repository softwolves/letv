package demo;

public class Demo04 {
	public static void main(String[] args) {
		Foo foo = new Foo();
		//foo.
	}
}
