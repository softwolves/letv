package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.EmpDAO;
import entity.Emp;

public class TestCase {
	@Test
	public void test1(){
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				"spring-mvc.xml");
		EmpDAO dao = 
				ac.getBean("empDAO",EmpDAO.class);
		Emp emp = new Emp();
		emp.setEname("Sally");
		emp.setAge(28);
		dao.save(emp);
	}
}
