package dao;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import entity.Emp;

@Repository("empDAO")
public class EmpDAO {
	
	@Resource(name="jt")
	private JdbcTemplate jt;
	
	/**
	 * JdbcTemplate对象提供了很多实用的方法，
	 * 我们不用考虑获取连接与关闭连接，
	 * 也不用考虑异常的处理(会将异常统一转
	 * 换成运行时异常，然后抛出)。
	 */
	public void save(Emp emp){
		String sql = 
		"INSERT INTO emp "
		+ "VALUES(emp_seq.nextval,?,?)";
		Object[] params = 
				new Object[]{emp.getEname(),
						emp.getAge()};
		jt.update(sql, params);
	}
}
