# Spring
## Spring IOC
- 控制反转
- 管理对象及对象的关系，降低他们的耦合度
- IOC是其他功能的基础
- Spring容器是IOC的核心

## Spring AOP
- 面向切面(方面)编程
- Filter可以统一处理多个Servlet共同的业务
- AOP可以统一处理一切对象的共同业务
- AOP可以降低共同业务和对象之间的耦合度

## Spring MVC
- 自动实现MVC，给代码分成
- 进一步降低Servlet及jsp内部的耦合度

## Spring整合
- Spring可以整合JDBC，提高开发效率
- Spring可以整合MyBatis、Hibernate，提高开发效率
- Spring可以整合Struts2，提高开发效率
- Spring可以降低这些技术中核心对象的耦合度