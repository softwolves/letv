package day03;

import java.util.ArrayList;
import java.util.Collection;

import day02.Point;

/**
 * ���ϴ��Ԫ�ش�ŵ���Ԫ�ص�����(��ַ)
 * @author Administrator
 *
 */
public class CollectionDemo3 {
	public static void main(String[] args) {
		Collection c = new ArrayList();
		Point p = new Point(1,2);
		c.add(p);
		System.out.println("p:"+p);
		System.out.println(c);//[(1,2)]
		
		p.setX(2);
		System.out.println("p:"+p);
		System.out.println(c);//[(2,2)]
	}
}








