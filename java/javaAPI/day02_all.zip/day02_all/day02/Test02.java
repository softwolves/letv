package day02;
/**
 * ͼƬ������
 * 1.jpg
 * 78612387431423.jpg
 * 
 * @author Administrator
 *
 */
public class Test02 {
	public static void main(String[] args) {
		String imgName = "1.jpg";
		String names[] = imgName.split("\\.");
		imgName = System.currentTimeMillis()
				  +"."+names[1];
		System.out.println(imgName);
	}
}



