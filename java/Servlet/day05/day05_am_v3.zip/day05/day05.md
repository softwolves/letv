# JSP隐含(内置)对象
## 1. request(*)
- HttpServletRequest

## 2. response
- HttpServletResponse

## 3. out
- JSPWriter
- 相当于PrintWriter

## 4. config
- ServletConfig

## 5. application
- ServletContext

## 6. exception
- Throwable
- 网页中的异常，当发生异常时才可用

## 7. session(*)
- HttpSession

## 8. page
- 指代当前页面，相当于this

## 9. pageContext(*)
- 可以给页面提供数据
- 事实上该对象内引用了其他8个隐含对象

## 使用示例
- <%=request.getParameter("user")%>
- <%String user = request.getParameter("user");%>