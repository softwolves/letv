# 增加员工
![](1.png)

# 重定向
![](2.png)

# 访问路径
![](3.png)

# URI和URL
![](4.png)

# Servlet路径的处理方式
![](5.png)

# Servlet生命周期
![](6.png)

# ServletConfig和ServletContext
![](7.png)