package oo.day03;
//super����ʾ
public class SuperDemo {
	public static void main(String[] args) {
	}
}

class Aoo{
	int a;
	Aoo(int a){
		this.a = a;
	}
}
class Boo extends Aoo{
	Boo(){
		super(5);
	}
}







