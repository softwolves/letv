package test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import entity.Emp;

public class TestCase {
	private SqlSession session;
	@Before
	public void init(){
		SqlSessionFactoryBuilder 
		ssfb = 
		new SqlSessionFactoryBuilder();
	SqlSessionFactory ssf = 
		ssfb.build(
		TestCase.class.getClassLoader().
		getResourceAsStream(
						"SqlMapConfig.xml"));
		session = 
			ssf.openSession();
	}
	
	@Test
	public void test1(){
		Emp emp = new Emp();
		emp.setEname("King");
		emp.setAge(22);
		session.insert("test.save", 
				emp);
		session.commit();
		session.close();
	}
	
	@Test
	public void test2(){
		List<Emp> emps = 
				session.selectList(
						"test.findAll");
		System.out.println(emps);
	}
	
	
	
	
	
	
}
