package com.tarena.oss.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 处理器类(二级控制器)
 *
 */
@Controller
public class LoginController {
	@RequestMapping("/toLogin.do")
	public String toLogin(){
		return "login";
	}
	
}






