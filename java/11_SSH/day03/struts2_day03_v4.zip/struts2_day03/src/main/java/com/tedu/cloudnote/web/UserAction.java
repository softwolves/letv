package com.tedu.cloudnote.web;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.interceptor.SessionAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.tedu.cloudnote.entity.User;
import com.tedu.cloudnote.service.UserService;
import com.tedu.cloudnote.util.NoteResult;

@Controller
public class UserAction extends BaseAction{

	private String username;
	private String password;
	public void setPassword(String password) {
		this.password = password;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String login(){
		NoteResult result = 
				userService.checkLogin(
				username, password);
		this.result=result;
		if(result.getStatus()==0){
			User user=(User)result.getData();
			session.put("loginUser", user);
		}
		return "success";
	}
}





