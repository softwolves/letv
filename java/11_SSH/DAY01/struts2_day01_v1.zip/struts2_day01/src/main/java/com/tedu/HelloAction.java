package com.tedu;

public class HelloAction {
	/**
	 * 方法名必须是execute
	 */
	public String execute(){
		System.out.println("Hello World!"); 
		//返回值时候success
		return "success";
	}
}
