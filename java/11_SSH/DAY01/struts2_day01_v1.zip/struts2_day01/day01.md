# Struts2



## 配置Struts2

配置步骤：

1. 下载Struts2的jar包
	- 从struts.apache.org 下载
		1. 解压缩
		2. 将*.jar复制到 /WEB-INF/lib 文件夹
	- 使用maven下载
		- 使用Eclipse内嵌搜索，搜索到 struts2-core 的“坐标(xml)”，保存pom.xml
		- 使用 maven.tedu.cn/nexus (maven.aliyun.com/nextus) 在线搜索, 搜索到 struts2-core 的“坐标(xml)”，保存pom.xml
2. 配置主控制器
	- 控制器类
		- org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter
		- 在struts-core-xxxx.jar 包中
	- 编辑文件 web.xml(部署描述文件)
		- filter
		- filter-mapping
3. 添加struts的配置文件
	- 位置：package中（classpath中）
	- 文件名：struts.xml, struts的filter会自动按照文件名struts.xml找到这个文件, 文件名不能错！！！

web.xml: 

	<?xml version="1.0" encoding="UTF-8"?>
	<web-app xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://java.sun.com/xml/ns/javaee" xsi:schemaLocation="http://java.sun.com/xml/ns/javaee http://java.sun.com/xml/ns/javaee/web-app_2_5.xsd" version="2.5">
	  <!-- Struts2 MVC 配置 -->
	  <!-- filter 会自动找package中的struts.xml -->
	  <filter>
	  	<filter-name>mvc</filter-name>
	  	<filter-class>
	  	org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter
	  	</filter-class>
	  </filter>
	  <filter-mapping>
	  	<filter-name>mvc</filter-name>
	  	<url-pattern>*.action</url-pattern>
	  </filter-mapping>

	</web-app>

## Hello World！步骤

1. 修改配置文件struts.xml 添加web请求的处理路径
	- <package name="test" namespace="/test" extends="struts-default">
		- namespace="/test" 表示处理一级路径 /test
		- extends="struts-default" 继承现有struts的参数
	- <action name="hello" class="com.tedu.HelloAction">
		- name="hello"处理2级路径 /test/hello.action
		- class="com.tedu.HelloAction" 
			- 在处理url请求时候执行HelloAction 的 execute() 方法，
			- execute方法一定有String返回值，常见的值有 "success" "error"
	- <result name="success">/WEB-INF/msg.jsp</result>
		- 与action方法的返回值配合, 表示返回 “success”时候，转发到msg.jsp页面，msg.jsp作为用户看的视图。
2. 添加类 com.tedu.HelloAction
	- 包含 String execute()
	- 方法中 return "success";
3. 添加  /WEB-INF/msg.jsp


struts.xml 文件参考：
	
	<?xml version="1.0" encoding="UTF-8"?>
	<!-- struts.xml -->
	<!DOCTYPE struts PUBLIC
		"-//Apache Software Foundation//DTD Struts Configuration 2.3//EN"
		"http://struts.apache.org/dtds/struts-2.3.dtd">
	<struts>
		<!-- 用于配置请求路径与控制器的匹配关系 -->
		<!-- /test 请求被这个包进行处理 -->
		<package name="test" namespace="/test"
			extends="struts-default"> 
			<!-- 请求/test/hello.action时候
			执行HelloAction的execute()方法 -->
			<action name="hello"
				class="com.tedu.HelloAction">
				<!-- execute方法返回success 
				时候，转发到msg.jsp-->
				<result name="success">
					/WEB-INF/msg.jsp
				</result>
			</action>
		</package>
	</struts>

HelloAction.java :

		
	package com.tedu;
	
	public class HelloAction {
		/**
		 * 方法名必须是execute
		 */
		public String execute(){
			System.out.println("Hello World!"); 
			//返回值时候success
			return "success";
		}
	}


msg.jsp:

	<%@ page language="java" 
		contentType="text/html; charset=UTF-8"
	    pageEncoding="UTF-8" %>
	<!DOCTYPE html>
	<html>
		<head>
			<meta charset="utf-8">
			<title>Hello</title>
		</head>
		<body>
			<h1>Hello World!</h1>
		</body>
	</html>






