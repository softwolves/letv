package com.tedu;

public class Login2Action {
	private User user;
	public void setUser(User user) {
		this.user = user;
	}
	public User getUser() {
		return user;
	}
	public String execute(){
		System.out.println(user); 
		//其他登录逻辑
		return "success";
	}
}



