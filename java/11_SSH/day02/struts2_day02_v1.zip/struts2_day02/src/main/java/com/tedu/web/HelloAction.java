package com.tedu.web;

import org.springframework.stereotype.Controller;

@Controller
public class HelloAction {
	public String execute(){
		System.out.println("Hello World!"); 
		return "success";
	}
}
