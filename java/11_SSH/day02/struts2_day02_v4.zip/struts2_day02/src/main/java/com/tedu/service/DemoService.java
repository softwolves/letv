package com.tedu.service;

import org.springframework.stereotype.Service;

@Service
public class DemoService {
	public void hello(){
		System.out.println("Hello!");
	}
}
