package com.tedu.web;

import org.springframework.stereotype.Controller;

@Controller
public class JsonAction {
	private int id;
	public int getId() {
		return id;
	}
	private String message;
	public String getMessage() {
		return message;
	}
	public String execute(){
		id = 100;
		message="Hello!";
		return "success";
	}
}




