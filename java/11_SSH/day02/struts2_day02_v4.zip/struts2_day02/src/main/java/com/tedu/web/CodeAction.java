package com.tedu.web;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.management.RuntimeErrorException;

import org.springframework.stereotype.Controller;

@Controller
public class CodeAction {
	
	public InputStream png;
	
	public String execute(){
		//生成图片流， 放到png中
		BufferedImage img = new BufferedImage(
			100, 38, BufferedImage.TYPE_3BYTE_BGR);
		for(int x=0;x<img.getWidth();x++){
			for(int y=0;y<img.getHeight();y++){
				int color = 
					(int)(Math.random()*0xffffff);
				img.setRGB(x, y, color);
			}
		}
		Graphics2D g = img.createGraphics();
		int color = 
			(int)(Math.random()*0xffffff);
		g.setColor(new Color(color));
		Font font=new Font(Font.SANS_SERIF,
				Font.BOLD, 30);
		g.setFont(font);
		g.drawString("3415", 10, 30);
		for(int i=0; i<5; i++){
			color = 
				(int)(Math.random()*0xffffff);
			g.setColor(new Color(color));
			int x1=(int)(Math.random()*100);
			int x2=(int)(Math.random()*100);
			int y1=(int)(Math.random()*38);
			int y2=(int)(Math.random()*38);
			g.drawLine(x1, y1, x2, y2);
		}
		
		ByteArrayOutputStream out =
			new ByteArrayOutputStream();
		try{
		//把图片对象编码为byte数组
			ImageIO.write(img, "png", out);
			out.close();
		}catch(IOException e){
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		byte[] data=out.toByteArray();
		png = new ByteArrayInputStream(data);
		return "success";
	}
}



