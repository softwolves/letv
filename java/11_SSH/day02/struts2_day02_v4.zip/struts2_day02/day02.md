# Struts2

## Spring + Struts2

Struts2 提供了 spring 整合插件 struts2-spring-plugin.jar

只要将这个插件添加到/WEB-INF/lib 文件夹中，就会自动将spring整合到Struts2. 整合以后Struts2 的Action对象将由Spring容器创建

![](spring-plugin.png)

### 1. 手工整合

1. 分别到Spring和Struts2网站下载jar包
2. 将jar包复制到/WEB-INF/lib 文件夹中
3. 修改web.xml文件添加Spring容器初始化监听器
4. 添加Spring配置文件。

> 提示： 这个整合过程过于繁琐，请同学自行实验，正是这个整合过程非常繁琐，才能体现Maven这种自动化工具的优点。

### 2. 利用Maven整合

1. 创建Maven项目，导入Struts2组件，并且配置struts.xml和web.xml
	- `<dependency>`
  	- `	<groupId>org.apache.struts</groupId>`
  	- `	<artifactId>struts2-core</artifactId>`
  	- `	<version>2.3.8</version>`
  	- `</dependency>`
	- 配置struts.xml和web.xml 请参考day01.html
2. 找到struts2-spring组件坐标添加到Struts2项目的pom.xml，然后保存
	- `<dependency>`
  	- `	<groupId>org.apache.struts</groupId>`
  	- `	<artifactId>struts2-spring-plugin</artifactId>`
  	- `	<version>2.3.8</version>`
  	- `</dependency>`
	- 注意：插件版本必须与 Struts2 的版本必须一致！！！
	- Maven会自动导入插件依赖的Spring包。**这是Maven最便捷的特点**。
3. 配置web.xml，利用Spring提供的监听器在Web容器启动时候初始化Spring容器。
	- `<listener>`
  	- `	<listener-class>`
  	- `		org.springframework.web.context.ContextLoaderListener`
  	- `	</listener-class>`
  	- `</listener>`
  	- `<context-param>`
  	- `	<param-name>contextConfigLocation</param-name>`
  	- `	<param-value>classpath:spring-*.xml</param-value>`
  	- `</context-param>`
	- 其中context-param用于指定Spring配置文件的存储位置
4. 创建Spring配置文件： spring-context.xml 
	- 注意这个配置文件要与 Spring版本配合，版本不能错误。
5. 启动容器进行测试。

参考代码：

pom.xml(片段):

	<dependencies>
	  	<dependency>
	  		<groupId>org.apache.struts</groupId>
	  		<artifactId>struts2-core</artifactId>
	  		<version>2.3.8</version>
	  	</dependency>
	  	<dependency>
	  		<groupId>org.apache.struts</groupId>
	  		<artifactId>struts2-spring-plugin</artifactId>
	  		<version>2.3.8</version>
	  	</dependency>
	</dependencies>

web.xml 片段：

	<!-- 配置 Listener 用于初始化Spring容器  -->
	<!-- 在Web容器启动时候自动初始化Spring容器-->
	<listener>
	  	<listener-class>
	  	org.springframework.web.context.ContextLoaderListener
	  	</listener-class>
	</listener>
	<!-- 配置Spring配置文件的位置 -->
	<context-param>
	  	<param-name>contextConfigLocation</param-name>
	  	<param-value>classpath:spring-*.xml</param-value>
	</context-param>
	
	<!-- Struts2 主控制器配置 -->
	<filter>
	  	<filter-name>mvc</filter-name>
	  	<filter-class>
	org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter
	  	</filter-class>
	</filter>
	<filter-mapping>
	  	<filter-name>mvc</filter-name>
	  	<url-pattern>/*</url-pattern>
	</filter-mapping>
 
struts.xml:

	<?xml version="1.0" encoding="UTF-8"?>
	<!DOCTYPE struts PUBLIC
		"-//Apache Software Foundation//DTD Struts Configuration 2.3//EN"
		"http://struts.apache.org/dtds/struts-2.3.dtd">
	<struts>
	</struts>

spring-context.xml:

	<?xml version="1.0" encoding="UTF-8"?>
	<beans xmlns="http://www.springframework.org/schema/beans"
		xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:context="http://www.springframework.org/schema/context"
		xmlns:jdbc="http://www.springframework.org/schema/jdbc" xmlns:jee="http://www.springframework.org/schema/jee"
		xmlns:tx="http://www.springframework.org/schema/tx" xmlns:aop="http://www.springframework.org/schema/aop"
		xmlns:mvc="http://www.springframework.org/schema/mvc" xmlns:util="http://www.springframework.org/schema/util"
		xmlns:jpa="http://www.springframework.org/schema/data/jpa"
		xsi:schemaLocation="
			http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.0.xsd
			http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-3.0.xsd
			http://www.springframework.org/schema/jdbc http://www.springframework.org/schema/jdbc/spring-jdbc-3.0.xsd
			http://www.springframework.org/schema/jee http://www.springframework.org/schema/jee/spring-jee-3.0.xsd
			http://www.springframework.org/schema/tx http://www.springframework.org/schema/tx/spring-tx-3.0.xsd
			http://www.springframework.org/schema/data/jpa http://www.springframework.org/schema/data/jpa/spring-jpa-1.3.xsd
			http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop-3.0.xsd
			http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc-3.0.xsd
			http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util-3.0.xsd">
	
	</beans>

### 3. 编写测试案例测试整合结果

 







