# w3c网站
- www.w3school.com.cn
- doc.tedu.cn

# 数组排序
![](1.png)

# 登录验证
![](2.png)

# arguments
![](3.png)